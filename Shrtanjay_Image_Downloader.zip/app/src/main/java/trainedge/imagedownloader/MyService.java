package trainedge.imagedownloader;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.IBinder;
import android.support.annotation.IntDef;
import android.support.design.widget.Snackbar;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MyService extends Service {

    private String url;
    private String image;

    public MyService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        if (intent != null) {

            url = intent.getStringExtra("trainedge.imagedownloader.MainActivity.UR");
            image = intent.getStringExtra("trainedge.imagedownloader.MainActivity.IMAGE");
            DownloaderNotification.notify(this,"Downloading...");

            new DownloadImage().execute(url);
        }
        return START_STICKY;
    }
    class DownloadImage extends AsyncTask<String, Void, Bitmap> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Bitmap doInBackground(String... url) {

            String imageURL = url[0];

            Bitmap bitmap = null;
            try {
                InputStream input = new java.net.URL(imageURL).openStream();
                bitmap = BitmapFactory.decodeStream(input);
                publishProgress();
            } catch (Exception e) {
                e.printStackTrace();
            }
            //Toast.makeText(SubActivity.this, "image downloaded", Toast.LENGTH_SHORT).show();
            return bitmap;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            Toast.makeText(MyService.this, "Still Downloading", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onPostExecute(Bitmap result) {
            DownloaderNotification.notify(MyService.this,"Downloading....");
            File sdcard = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) ;

            File folder = new File(sdcard.getAbsoluteFile().getAbsolutePath());//the dot makes this directory hidden to the user
            folder.mkdir();
            File file = new File(folder.getAbsoluteFile(), image + ".jpg") ;

          /*  if (file.exists())
            {
                Toast.makeText(MyService.this, "image already exists", Toast.LENGTH_SHORT).show();

            }*/

            try {
                FileOutputStream out = new FileOutputStream(file);
                result.compress(Bitmap.CompressFormat.JPEG, 90, out);
                out.flush();
                out.close();
                Toast.makeText(MyService.this, "Downloaded", Toast.LENGTH_SHORT).show();

            } catch (Exception e) {
                e.printStackTrace();
            }
           /* String fil=image+".jpg";
            SharedPreferences sp=getSharedPreferences("my preff",MODE_PRIVATE);
            SharedPreferences.Editor ed=sp.edit();
            ed.putString("file_key",fil);*/
            Intent i=new Intent(MyService.this,GalleryActivity.class);
            startActivity(i);


        }


    }
    }


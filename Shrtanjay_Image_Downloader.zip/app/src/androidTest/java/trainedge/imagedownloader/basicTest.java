package trainedge.imagedownloader;


import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.pressBack;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.longClick;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withContentDescription;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class basicTest {

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule = new ActivityTestRule<>(MainActivity.class);

    @Test
    public void basicTest() {
        ViewInteraction appCompatEditText = onView(
                allOf(withId(R.id.ettext), isDisplayed()));
        appCompatEditText.perform(click());

        ViewInteraction appCompatEditText2 = onView(
                allOf(withId(R.id.ettext), isDisplayed()));
        appCompatEditText2.perform(click());

        ViewInteraction appCompatEditText3 = onView(
                allOf(withId(R.id.ettext), isDisplayed()));
        appCompatEditText3.perform(longClick());

        // Added a sleep statement to match the app's execution delay.
        // The recommended way to handle such scenarios is to use Espresso idling resources:
        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
        try {
            Thread.sleep(50);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ViewInteraction appCompatEditText4 = onView(
                allOf(withId(R.id.ettext), isDisplayed()));
        appCompatEditText4.perform(click());

        ViewInteraction appCompatEditText5 = onView(
                allOf(withId(R.id.ettext), isDisplayed()));
        appCompatEditText5.perform(longClick());

        // Added a sleep statement to match the app's execution delay.
        // The recommended way to handle such scenarios is to use Espresso idling resources:
        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
        try {
            Thread.sleep(50);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ViewInteraction linearLayout = onView(
                allOf(withContentDescription("Paste"), isDisplayed()));
        linearLayout.perform(click());

        ViewInteraction appCompatEditText6 = onView(
                allOf(withId(R.id.ettext), isDisplayed()));
        appCompatEditText6.perform(replaceText("http://www.trivalleystargazers.org/gert/CCD_Galery/ngc6611_st10_l2_txt.jpg"), closeSoftKeyboard());

        ViewInteraction linearLayout2 = onView(
                allOf(withContentDescription("Paste"), isDisplayed()));
        linearLayout2.perform(click());

        ViewInteraction appCompatEditText7 = onView(
                allOf(withId(R.id.ettext), withText("http://www.trivalleystargazers.org/gert/CCD_Galery/ngc6611_st10_l2_txt.jpg"), isDisplayed()));
        appCompatEditText7.perform(replaceText("http://www.trivalleystargazers.org/gert/CCD_Galery/ngc6611_st10_l2_txt.jpghttp://www.trivalleystargazers.org/gert/CCD_Galery/ngc6611_st10_l2_txt.jpg"), closeSoftKeyboard());

        pressBack();

        ViewInteraction appCompatEditText8 = onView(
                allOf(withId(R.id.etname), isDisplayed()));
        appCompatEditText8.perform(replaceText("bhhb"), closeSoftKeyboard());

        pressBack();

        ViewInteraction appCompatEditText9 = onView(
                allOf(withId(R.id.etname), withText("bhhb"), isDisplayed()));
        appCompatEditText9.perform(click());

        pressBack();

        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.btdown), withText("download"), isDisplayed()));
        appCompatButton.perform(click());

    }

}

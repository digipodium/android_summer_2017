package trainedge.touristloc.holders;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import trainedge.touristloc.R;

/**
 * Created by kishan on 16-07-2017.
 */

public class LocationHolder extends RecyclerView.ViewHolder {
    public TextView tvlat;
    public TextView tvlng;
    public TextView tvemail;


    public LocationHolder(View itemView) {
        super(itemView);
        tvlat=(TextView)itemView.findViewById(R.id.tvlat);
        tvlng=(TextView)itemView.findViewById(R.id.tvlng);
        tvemail=(TextView)itemView.findViewById(R.id.tvemail);
    }

}


package trainedge.touristloc.models;

/**
 * Created by kishan on 16-07-2017.
 */

public class Location {
    double lat, lng;
    String email;

    public Location() {
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Location(double lat, double lng, String email) {

        this.lat = lat;
        this.lng = lng;
        this.email = email;
    }
}

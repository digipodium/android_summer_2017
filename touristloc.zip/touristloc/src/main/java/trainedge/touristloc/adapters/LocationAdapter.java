package trainedge.touristloc.adapters;

/**
 * Created by kishan on 16-07-2017.
 */

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import trainedge.touristloc.R;
import trainedge.touristloc.holders.LocationHolder;
import trainedge.touristloc.models.Location;

/**
 * Created by kishan on 01-07-2017.
 */

public class LocationAdapter extends RecyclerView.Adapter<LocationHolder> {
    Context context;
    ArrayList<Location> LocationItem;

    public LocationAdapter(Context context, ArrayList<Location> LocationItem) {
        this.context = context;
        this.LocationItem = LocationItem;
    }




    @Override
    public LocationHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(context).inflate(R.layout.simple_card_item,parent,false);
        return new LocationHolder(v);
    }

    @Override
    public void onBindViewHolder(LocationHolder holder, int position) {
        Location location= LocationItem.get(position);
        holder.tvemail.setText(location.getEmail());
        holder.tvlat.setText(String.valueOf(location.getLat()));
        holder.tvlng.setText(String.valueOf(location.getLng()));



    }

    @Override
    public int getItemCount() {
        return LocationItem.size();
    }


}

package trainedge.touristloc;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;

import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;

    private EditText etEmail;
    private EditText etPassword;
    private Button btnsign;
    private Button btnsignup;


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                //case R.id.navigation_home:
                    //mTextMessage.setText(R.string.title_home);
                    //return true;
                //case R.id.navigation_dashboard:
                    //mTextMessage.setText(R.string.title_dashboard);
                    //return true;
                //case R.id.navigation_notifications:
                // mTextMessage.setText(R.string.title_notifications);
               // case R.id.logout:
                    // mTextMessage.setText(R.string.title_notifications);
                    //FirebaseAuth.getInstance().signOut();
                    //Intent intent=new Intent(HomeActivity.this,MainActivity.class);
                    //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    //return true;

            }
            return false;
        }

    };
    private ProgressBar pbstatus;
    private FusedLocationProviderClient mFusedLocationClient;
    private TextView tvfr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        //getSupportActionBar().setTitle("Welcome");


        etEmail = (EditText) findViewById(R.id.etEmail);
        etPassword= (EditText)findViewById(R.id.etPassword);
        btnsign =(Button)findViewById(R.id.btnsign);
        btnsignup =(Button)findViewById(R.id.btnsignup);
        btnsign.setOnClickListener(this);
        btnsignup.setOnClickListener(this);
        pbstatus = (ProgressBar) findViewById(R.id.pbstatus);
        mAuth = FirebaseAuth.getInstance();


        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    // User is signed in
                    //Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
                    Intent homeIntent = new Intent(MainActivity.this,HomeActivity.class);
                    homeIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(homeIntent);
                } else {
                    // User is signed out
                    // Log.d(TAG, "onAuthStateChanged:signed_out");
                }
                // ...
            }
        };






       //BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        //navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }


    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }
    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    @Override
    public void onClick(View view) {
        show();
        String email = etEmail.getText().toString();
        String password = etEmail.getText().toString();
        if (email.isEmpty()) {
            etEmail.setError("error found");
            return;
        }
        if (password.isEmpty() && password.length() < 8) {
            etPassword.setError("error");

        }
        switch (view.getId()){
            case R.id.btnsign :
                trylogin(email,password);
                break;
            case R.id.btnsignup:
                trySignup(email,password);
                break;

        }

        trylogin(email,password);

    }

    private void trySignup(String email, String password) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        hide();


                        // If sign in fails, display a message to the user. If sign in succeeds
                        // the auth state listener will be notified and logic to handle the
                        // signed in user can be handled in the listener.
                        if (!task.isSuccessful()) {
                            Toast.makeText(MainActivity.this,task.getException().getMessage(),
                                    Toast.LENGTH_SHORT).show();
                        }
                        else {
                            //firebae extra info for the user
                        }

                        // ...
                    }
                });
    }

    private void trylogin(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        hide();


                        // If sign in fails, display a message to the user. If sign in succeeds
                        // the auth state listener will be notified and logic to handle the
                        // signed in user can be handled in the listener.
                        if (!task.isSuccessful()) {

                            Toast.makeText(MainActivity.this, task.getException().getMessage(),
                                    Toast.LENGTH_SHORT).show();
                        }

                        // ...
                    }
                });

    }
    public void show(){
        pbstatus.setVisibility(View.VISIBLE);
    }
    public void hide(){
        pbstatus.setVisibility(View.GONE);
    }
}

package com.example.veeru.friendlocater;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        // Read from the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference db= database.getReference("locations");


        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue(String.class);
               // Log.d(TAG, "Value is: " + value);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
               // Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }
    private class ProductAdapter extends RecyclerView.Adapter<ProductHolder>{
        List<Friend> productList;
        public ProductAdapter(ListActivity activity,final  DatabaseReference productsDb){
            productList=new ArrayList<>();
            productsDb.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    productList.clear();
                    if (dataSnapshot.getChildrenCount()>0)
                    {
                        for(DataSnapshot snapshot: dataSnapshot.getChildren()){
                            productList.add(snapshot.getValue(Friend.class));
                            notifyDataSetChanged();
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });

        }

        @Override
        public ProductHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            View view= LayoutInflater.from(ListActivity.this)
                    .inflate(R.layout.friend_card,parent,false);
            return new ProductHolder(view);

        }

        @Override
        public void onBindViewHolder(ProductHolder holder, int position) {
        Friend friend=productList.get(position);
           holder.tvid.setText(friend.email);
           holder.tvad.setText(friend.address);
           holder.tvlat.setText(friend.latitude);
           holder.tvlng.setText(friend.longitude);
        }

        @Override
        public int getItemCount() {
            return productList.size();
        }
    }
    private class ProductHolder extends RecyclerView.ViewHolder{
        View tvid;
        View tvad;
        View tvlat;
        View tvlng;
        public ProductHolder(View itemView){
            super(itemView);
            tvid=itemView.findViewById(R.id.emailaddress);
            tvad=itemView.findViewById(R.id.tvaddress);
            tvlat=itemView.findViewById(R.id.tvlat);
            tvlng=itemView.findViewById(R.id.tvLong);
        }
    }
}

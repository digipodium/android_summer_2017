package com.example.veeru.friendlocater;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.os.ResultReceiver;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.internal.lo;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient client;
    private Location location;
    private AddressResultReceiver mResultReceiver;
    private CircleOptions circleOp;
    private String mAddressOutput;
    private Button viewl;
    private ArrayList<Friend> productList;

    // ...

    protected void startIntentService() {
        mResultReceiver = new AddressResultReceiver(new Handler());
        Intent intent = new Intent(this, AddressService.class);

        intent.putExtra(AddressService.Constants.RECEIVER, mResultReceiver);
        intent.putExtra(AddressService.Constants.LOCATION_DATA_EXTRA, location);
        startService(intent);
    }

    class AddressResultReceiver extends ResultReceiver {
        public AddressResultReceiver(Handler handler) {
            super(handler);
        }

        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData) {

            // Display the address string
            // or an error message sent from the intent service.
            mAddressOutput = resultData.getString(AddressService.Constants.RESULT_DATA_KEY);
            saveToFirebase();

            // Show a toast message if an address was found.
            if (resultCode == AddressService.Constants.SUCCESS_RESULT) {
                //showToast(getString(R.string.address_found));
            }

        }
    }

    private void saveToFirebase() {
        if (location != null && mAddressOutput != null) {
            FirebaseDatabase fb = FirebaseDatabase.getInstance();
            final DatabaseReference db = fb.getReference("locations");
            Friend friend = new Friend(FirebaseAuth.getInstance().getCurrentUser().getEmail(), mAddressOutput, location.getLatitude(), location.getLongitude());
            db.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(friend, new DatabaseReference.CompletionListener() {
                @Override
                public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                    if (databaseError == null) {
                        Toast.makeText(HomeActivity.this, "done!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(HomeActivity.this, "unable to update", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            // FirebaseDatabase instance = FirebaseDatabase.getInstance();
        } else {
            Toast.makeText(this, "there was an error updating ur location", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        client = new FusedLocationProviderClient(this);
        viewl = (Button) findViewById(R.id.viewl);
        viewl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(HomeActivity.this, ListActivity.class);
                startActivity(i);

            }
        });
        productList = new ArrayList<>();
        setupPermission();


    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 99) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getMyLocation();
            }
        }
    }

    public void setupPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION}, 99);

            } else {
                getMyLocation();
            }
        } else {
            getMyLocation();
        }
    }

    public void getMyLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        client.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    HomeActivity.this.location = location;
                    startIntentService();
                    updateUI();
                } else {
                    Toast.makeText(HomeActivity.this, "location null", Toast.LENGTH_SHORT).show();
                }

            }

        });

    }

    private void updateUI() {
        Toast.makeText(this, "fetching", Toast.LENGTH_SHORT).show();
        LatLng sydney = new LatLng(location.getLatitude(), location.getLongitude());
        mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
        mMap.getUiSettings().setCompassEnabled(true);
        mMap.addMarker(new MarkerOptions().position(sydney).title("My Location"));
        // mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(sydney, 15f));
        circleOp = new CircleOptions();
        circleOp.center(sydney);
        circleOp.radius(100);
        circleOp.fillColor(Color.argb(100, 255, 255, 55));
        mMap.addCircle(circleOp);

        FirebaseDatabase fb = FirebaseDatabase.getInstance();
        final DatabaseReference db = fb.getReference("locations");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                productList.clear();
                if (dataSnapshot.getChildrenCount() > 0) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        productList.add(snapshot.getValue(Friend.class));

                    }
                    if (mMap!=null){
                        for (Friend friend : productList) {
                            mMap.addMarker(new MarkerOptions().position(new LatLng((float) friend.latitude, (float) friend.longitude)).title(friend.email + "\n" + friend.address)).showInfoWindow();
                        }

                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

    }


}

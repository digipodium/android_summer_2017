package com.example.veeru.friendlocater;

/**
 * Created by veeru on 23-Sep-17.
 */

class Friend {

   public String email;
   public String address;
   public double latitude;
   public double longitude;

    public Friend() {

    }

    public Friend(String email, String address, double latitude, double longitude) {
        this.email = email;
        this.address = address;
        this.latitude = latitude;
        this.longitude = longitude;

    }
}

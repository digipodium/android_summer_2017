package com.example.webbrowser;

import android.app.Activity;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private WebView we;
    private Button b1;
    private EditText e1;
    private String add;
    private ProgressBar pb;


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);getWindow().requestFeature(Window.FEATURE_PROGRESS);
        setContentView(R.layout.activity_main);
        we = (WebView)findViewById(R.id.we);
        b1 = (Button)findViewById(R.id.b1);
        e1 = (EditText)findViewById(R.id.e1);
        b1.setOnClickListener(this);
        pb = (ProgressBar)findViewById(R.id.pb);
pb.setMax(100);
        pb.setVisibility(View.GONE);
        if(savedInstanceState!=null)
        {
            we.restoreState(savedInstanceState);
        }else {
            we.getSettings().setJavaScriptEnabled(true);
            we.getSettings().setSupportZoom(true);
            we.getSettings().setBuiltInZoomControls(true);
            we.getSettings().setLoadWithOverviewMode(true);
            we.getSettings().setUseWideViewPort(true);
            we.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);

            final Activity activity = this;

           we.setWebViewClient(new ourWebViewClient());
            we.setWebChromeClient(new WebChromeClient(){
                @Override
                public void onProgressChanged(WebView view, int newProgress) {
                    pb.setProgress(newProgress);
                    if(newProgress<100 && pb.getVisibility()==pb.GONE){
pb.setVisibility(ProgressBar.VISIBLE);
                    }
                    if(newProgress==100){
                        pb.setVisibility(ProgressBar.GONE);
                    }
                }
            });


        }  }

    @Override
    public void onClick(View v) {
        add = e1.getText().toString();



        we.loadUrl("http://"+add);
    }

    private class ourWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            CookieManager.getInstance().setAcceptCookie(true);
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
        }

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        we.saveState(outState);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.ba:
                if(we.canGoBack()){
                    we.goBack();
                }
                return  true;
            case R.id.f:
                if(we.canGoForward())
                {
                    we.goForward();
                }
                return  true;
            case R.id.ho:
                we.loadUrl("http://www.google.com");
                return  true;
            case R.id.b:
                return  true;
            case R.id.h:
                return  true;
        }
        return super.onOptionsItemSelected(item);
    }
}

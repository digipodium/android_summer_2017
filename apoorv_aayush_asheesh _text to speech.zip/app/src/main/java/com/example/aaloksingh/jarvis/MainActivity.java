package com.example.aaloksingh.jarvis;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    //Text to speech object in field
    private TextToSpeech speaker;
    private SeekBar sBSpeechRate;
    private SeekBar sBPitchRate;
    double pitch = 0.0f, SpeechRate = 0.0f;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sBPitchRate = (SeekBar) findViewById(R.id.sBPitchRate);
        sBSpeechRate = (SeekBar) findViewById(R.id.sBSpeechRate);

        speaker = new TextToSpeech(this,this);

    }


    public void buttonSpeakClicked(View view) {

        // Get Text from editText
        EditText editText = (EditText) findViewById(R.id.enterText);

        Editable input = editText.getText();

        //Convert to a string
        String phrase = input.toString();

        //speak the phrase
        int progress = sBPitchRate.getProgress();
        float pitch = progress / 100.0f;
        speaker.setPitch(pitch);
        float speechRate = sBSpeechRate.getProgress() / 100.0f;
        speaker.setSpeechRate(speechRate);
        speaker.speak(phrase, TextToSpeech.QUEUE_ADD, null, "sp");
    }//end buttonSpeakClicked()

    @Override
    public void onInit(int status) {

        speaker.speak("type some text ", TextToSpeech.QUEUE_ADD, null, "sp");
    }

    public void onDestroy() {
        if (speaker != null) {
            speaker.stop();
            speaker.shutdown();
        }
        super.onDestroy();
    }//end onDestroy

}//end class MainActivity

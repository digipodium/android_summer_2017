package trainedge.crowd;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class ViewMoviesAdapter extends RecyclerView.Adapter<ViewMoviesHolder> {
    Context context;
    ArrayList<ViewMoviesModel> list;


    public ViewMoviesAdapter(Context context, ArrayList<ViewMoviesModel> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public ViewMoviesHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.finalcomments, parent, false);
        return new ViewMoviesHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewMoviesHolder holder, int position) {
     final  ViewMoviesModel model = list.get(position);
        holder.tvReviews.setText(model.getMoviereviews());
        holder.tvRating.setRating(model.getRating());
        holder.tvEmail.setText(model.getEmail());
    }

    @Override
    public int getItemCount() {

        return list.size();
    }
}

package trainedge.crowd;


public class ViewMoviesModel {

    //Same name as in firebase data(moviereviews,rating)
    String moviereviews;
    float rating;
    String email;

    public ViewMoviesModel() {
    }

    public ViewMoviesModel(String moviereviews, float rating,String email) {
        this.moviereviews = moviereviews;
        this.rating = rating;
        this.email=email;
    }

    public String getMoviereviews() {
        return moviereviews;
    }

    public void setMoviereviews(String moviereviews) {
        this.moviereviews = moviereviews;
    }

    public  float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
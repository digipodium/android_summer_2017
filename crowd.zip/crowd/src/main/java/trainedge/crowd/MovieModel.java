package trainedge.crowd;


public class MovieModel {


    String name, image;
    int year;

    public MovieModel(String name, String image, int year) {
        this.name = name;
        this.image = image;
        this.year = year;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public MovieModel() {
    }
}



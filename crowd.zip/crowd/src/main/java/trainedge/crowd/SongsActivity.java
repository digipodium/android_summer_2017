package trainedge.crowd;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;

public class SongsActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageButton imgtzp;
    private ImageButton imgnahubali;
    private ImageButton imgdz;
    private ImageButton imgairlft;
    private ImageButton img3idiots;
    private ImageButton imgraees;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songs);

        imgtzp = (ImageButton) findViewById(R.id.imgtzp);
        imgtzp.setOnClickListener(this);
        imgnahubali = (ImageButton) findViewById(R.id.imgbahubali);
        imgnahubali.setOnClickListener(this);
        imgdz = (ImageButton) findViewById(R.id.imgdz);
        imgdz.setOnClickListener(this);
        imgairlft = (ImageButton) findViewById(R.id.imgairlift);
        imgairlft.setOnClickListener(this);
        img3idiots = (ImageButton) findViewById(R.id.img3idiots);
        img3idiots.setOnClickListener(this);
        imgraees = (ImageButton) findViewById(R.id.imgraees);
        imgraees.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        String url = "";
        switch (id) {
            case R.id.img3idiots:
                url = "https://mp3mad.com/search.php?ty=3+idiots&sh=Song&catz=All+Music";
                break;
            case R.id.imgairlift:
                url = "https://mp3mad.com/search.php?ty=airlift&sh=Song&catz=All+Music";
                break;
            case R.id.imgbahubali:
                url = "https://mp3mad.com/search.php?ty=bahubali&sh=Song&catz=Hindi";
                break;
            case R.id.imgdz:
                url = "https://mp3mad.com/search.php?ty=dear+zindagi&sh=Song&catz=Hindi";
                break;
            case R.id.imgraees:
                url = "https://mp3mad.com/search.php?ty=raees&sh=Song&catz=All+Music";
                break;
            case R.id.imgtzp:
                url = "https://mp3mad.com/10853/Taare-Zameen-Par-mp3-songs.html";
                break;
        }

        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }
}


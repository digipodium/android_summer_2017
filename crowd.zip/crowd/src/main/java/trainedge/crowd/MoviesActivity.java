package trainedge.crowd;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class MoviesActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener, ValueEventListener {
    private EditText etQuote;
    private FloatingActionButton fabDone;
    private ProgressBar pbStatus;
    private BottomNavigationView navigation;
    private DatabaseReference db;
    private ArrayList<MovieModel> list;
    private MovieAdapter adapter;
    private RecyclerView rvList;
    private TextView tvHeader1;
    private ProgressDialog mProgressDialog;
    //private MenuItem itemUser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movies);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);




        FirebaseDatabase fd=FirebaseDatabase.getInstance();
        db = fd.getReference("movies");
        list = new ArrayList<MovieModel>();
        db.addValueEventListener(this);
        /*Recycler view code */
        rvList = (RecyclerView) findViewById(R.id.rvList);
        rvList.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MovieAdapter(this,list);
        rvList.setAdapter(adapter);

        tvHeader1 = (TextView) findViewById(R.id.tvHeader1);
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setMessage("Loading....");
        mProgressDialog.show();
        mProgressDialog.setCanceledOnTouchOutside(false);
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        String email = currentUser.getEmail();



        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View hView=navigationView.getHeaderView(0);
        tvHeader1 = (TextView)hView.findViewById(R.id.tvHeader1);
        tvHeader1.setText(email);
        /*itemUser= (MenuItem) findViewById(R.id.itemUser);
        int i=email.indexOf('@');
        String s=email.substring(0,i);
        s="Hi " + s;
        itemUser.setTitle(s);*/

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.navi, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            FirebaseAuth.getInstance().signOut();
            // go to main
            Intent intent = new Intent(MoviesActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            Intent i=new Intent(MoviesActivity.this,SongsActivity.class);

            startActivity(i);

            // Handle the camera action
        } else if (id == R.id.nav_gallery) {
            Intent i=new Intent(MoviesActivity.this,ComingSoonActivity.class);

            startActivity(i);

        } else if (id == R.id.nav_slideshow) {
            Intent i=new Intent(MoviesActivity.this,VideosActivity.class);

            startActivity(i);

        } else if (id == R.id.nav_manage) {
            Intent i=new Intent(MoviesActivity.this,MoviesActivity.class);

            startActivity(i);

        } else if (id == R.id.nav_share) {
            Intent i=new Intent(MoviesActivity.this,FeedbackActivity.class);

            startActivity(i);

        } else if (id == R.id.nav_send) {

                FirebaseAuth.getInstance().signOut();
                // go to main
                Intent intent = new Intent(MoviesActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                return true;
            }



        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View v) {
        show();
        int id = v.getId();
        switch (id) {
            case R.id.btn:
                Intent i = new Intent(MoviesActivity.this, MoviesActivity.class);
                startActivity(i);
                break;
            case R.id.fab:
                String userQuote = etQuote.getText().toString().trim();
                if (userQuote.isEmpty()) {
                    return;
                }

                addToFirebase(userQuote);
                etQuote.setText("");
                break;
        }
    }


    private void addToFirebase(String userQuote) {
        // etQuote.setText(""); //this line can be here and can be in onclick()also...
        //FirebaseDatabase
      /*  FirebaseDatabase fd=FirebaseDatabase.getInstance();
        DatabaseReference db=fd.getReference("Quotes");
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        String email = currentUser.getEmail();
        HashMap<String,Object> map= new HashMap<>();
        map.put("quote",userQuote);
        map.put("email",email);


        db.push().setValue(map, new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                hide();
                if (databaseError==null){
                    Toast.makeText(MoviesActivity.this, "Success", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MoviesActivity.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });*/
    }



    @Override
    public void onDataChange(DataSnapshot dataSnapshot) {
        if(dataSnapshot.hasChildren()){
            list.clear();
            for (DataSnapshot snapshot : dataSnapshot.getChildren())
            {
                list.add(snapshot.getValue(MovieModel.class));
            }
            adapter.notifyDataSetChanged();
            mProgressDialog.dismiss();
        }
        else
        {
            mProgressDialog.dismiss();
            Toast.makeText(this, "NO DATA YET.", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onCancelled(DatabaseError databaseError) {

        if (databaseError!=null)
        {
            Toast.makeText(this, "Error" +databaseError.getMessage(), Toast.LENGTH_SHORT).show();
        }


    }


    public void hide() {
        pbStatus.setVisibility(View.GONE);
    }

    public void show() {
        pbStatus.setVisibility(View.VISIBLE);
    }
}

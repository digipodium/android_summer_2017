package trainedge.crowd;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;

import java.util.ArrayList;



public class MovieAdapter extends RecyclerView.Adapter<MovieHolder> {
    public static final String EXTRA_NAME = "trainedge.crowd.EXTRA_NAME";
    Context context;
    ArrayList<MovieModel> list;

    public MovieAdapter(Context context, ArrayList<MovieModel> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public MovieHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.abc, parent, false);
        return new MovieHolder(v);
    }

    @Override
    public void onBindViewHolder(MovieHolder holder, int position) {
        final MovieModel model = list.get(position);
        holder.tvMovieName.setText(model.getName());
        holder.tvyear.setText(String.valueOf(model.getYear()));
        Glide.with(context).load(model.image).into(holder.imgUrl);

        holder.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, ViewMovies.class);
                i.putExtra(EXTRA_NAME, model.getName());
                context.startActivity(i);

            }
        });

    }

    @Override
    public int getItemCount() {

        return list.size();
    }


}

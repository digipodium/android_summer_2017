package trainedge.crowd;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class VideosActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageButton imgtzp;
    private ImageButton imgnahubali;
    private ImageButton imgdz;
    private ImageButton imgairlft;
    private ImageButton img3idiots;
    private ImageButton imgraees;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videos);
        imgtzp = (ImageButton) findViewById(R.id.imgtzp);
        imgtzp.setOnClickListener(this);
        imgnahubali = (ImageButton) findViewById(R.id.imgbahubali);
        imgnahubali.setOnClickListener(this);
        imgdz = (ImageButton) findViewById(R.id.imgdz);
        imgdz.setOnClickListener(this);
        imgairlft = (ImageButton) findViewById(R.id.imgairlift);
        imgairlft.setOnClickListener(this);
        img3idiots = (ImageButton) findViewById(R.id.img3idiots);
        img3idiots.setOnClickListener(this);
        imgraees = (ImageButton) findViewById(R.id.imgraees);
        imgraees.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        String url = "";
        switch (id) {
            case R.id.img3idiots:
                url = "https://www.youtube.com/watch?v=fzDyTacHufo";
                break;
            case R.id.imgairlift:
                url = "https://www.youtube.com/watch?v=M6t9YNsVonM";
                break;
            case R.id.imgbahubali:
                url = "https://www.youtube.com/user/BaahubaliOfficial";
                break;
            case R.id.imgdz:
                url = "https://www.youtube.com/watch?v=ORKh5EmnLoA";
                break;
            case R.id.imgraees:
                url = "https://www.youtube.com/watch?v=9NUf22Qsz5Q";
                break;
            case R.id.imgtzp:
                url = "https://www.youtube.com/watch?v=rd2oIOqZNGA";
                break;
        }

        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }
}

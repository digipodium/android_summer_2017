package trainedge.crowd;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.RatingBar;
import android.widget.TextView;


public class ViewMoviesHolder  extends RecyclerView.ViewHolder{
    TextView tvReviews;
    RatingBar tvRating;
    TextView tvEmail;



    public ViewMoviesHolder(View itemView) {
        super(itemView);
        tvReviews= (TextView) itemView.findViewById(R.id.tvReviews);
        tvRating= (RatingBar) itemView.findViewById(R.id.tvRating);
        tvEmail= (TextView) itemView.findViewById(R.id.tvEmail);


    }


}

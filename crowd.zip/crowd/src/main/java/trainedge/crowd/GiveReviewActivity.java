package trainedge.crowd;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class GiveReviewActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {
    private DatabaseReference db;
    private EditText etReview;
    private RatingBar etRating;
    private FloatingActionButton fabDone;
    private String movieId;
    private ImageView movieImage;
    private TextView tvYear;
    private TextView tvName;
    private TextView tvHeader3;
    private String email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_give_review);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        email = currentUser.getEmail();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View hView=navigationView.getHeaderView(0);
        tvHeader3 = (TextView) hView.findViewById(R.id.tvHeader3);
        tvHeader3.setText(email);

        movieId = getIntent().getStringExtra(ViewMovies.PACKAGE + ".key_moviename");

        updateUI();

        etRating = (RatingBar) findViewById(R.id.etRating);
        etReview = (EditText) findViewById(R.id.etReview);
        tvName = (TextView) findViewById(R.id.tvName);
        tvYear = (TextView) findViewById(R.id.tvYear);
        movieImage = (ImageView) findViewById(R.id.movieImage);
        fabDone = (FloatingActionButton) findViewById(R.id.fabDone);
        fabDone.setOnClickListener(this);
    }

    private void updateUI() {
        FirebaseDatabase.getInstance().getReference("movies").child(movieId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChildren()) {
                    String imageUrl = dataSnapshot.child("image").getValue(String.class);
                    String name = dataSnapshot.child("name").getValue(String.class);
                    int year = dataSnapshot.child("year").getValue(Integer.class);

                    tvName.setText(name);
                    tvYear.setText(String.valueOf(year));
                  try {
                        Glide.with(getApplicationContext()).load(imageUrl).into(movieImage);
                    } catch (Exception e) {

                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.give_review, menu);
        MenuItem menuItems = menu.findItem(R.id.itemUser3);
        int i=email.indexOf('@');
        String s=(email.substring(0,i));
        String sa="Hi " + s + "!!";
        menuItems.setTitle(sa);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            FirebaseAuth.getInstance().signOut();
            // go to main
            Intent intent = new Intent(GiveReviewActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        if (id == R.id.nav_camera) {
            Intent i=new Intent(GiveReviewActivity.this,SongsActivity.class);

            startActivity(i);

            // Handle the camera action
        } else if (id == R.id.nav_gallery) {
            Intent i=new Intent(GiveReviewActivity.this,ComingSoonActivity.class);

            startActivity(i);

        } else if (id == R.id.nav_slideshow) {
            Intent i=new Intent(GiveReviewActivity.this,VideosActivity.class);

            startActivity(i);

        } else if (id == R.id.nav_manage) {
            Intent i=new Intent(GiveReviewActivity.this,MoviesActivity.class);

            startActivity(i);

        } else if (id == R.id.nav_share) {
            Intent i=new Intent(GiveReviewActivity.this,FeedbackActivity.class);

            startActivity(i);

        } else if (id == R.id.nav_send) {

                FirebaseAuth.getInstance().signOut();
                // go to main
                Intent intent = new Intent(GiveReviewActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                return true;
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View v) {
        String userReview = etReview.getText().toString().trim();
        float rating = etRating.getRating();



        if (userReview.isEmpty() || rating == 0.0) {
           Toast.makeText(this, "Cannot Leave This Empty", Toast.LENGTH_SHORT).show();
        }
        else {
            addToFirebase(userReview, rating);
            etReview.setText("");
            etRating.setRating(0.0f);
            Intent i= new Intent(GiveReviewActivity.this,MoviesActivity.class);
            startActivity(i);
        }
    }

    private void addToFirebase(String userReview, float rating) {
        FirebaseDatabase fd = FirebaseDatabase.getInstance();
        DatabaseReference db = fd.getReference("reviews").child(movieId);
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        String email = currentUser.getEmail();
        HashMap<String, Object> map = new HashMap<>();
        map.put("email", email);
        map.put("moviereviews", userReview);
        map.put("rating", rating);


        db.push().setValue(map, new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {

                if (databaseError == null) {
                    Toast.makeText(GiveReviewActivity.this, "Success", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(GiveReviewActivity.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

package trainedge.crowd;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;



public class MovieHolder extends RecyclerView.ViewHolder{
    TextView tvMovieName;
    TextView tvyear;
    ImageView imgUrl;
    Button btn;




    public MovieHolder(View itemView) {
        super(itemView);
        tvMovieName= (TextView) itemView.findViewById(R.id.tvMovieName);
        tvyear= (TextView) itemView.findViewById(R.id.tvyear);
        imgUrl= (ImageView) itemView.findViewById(R.id.imgUrl);
        btn= (Button) itemView.findViewById(R.id.btn);

    }


}


package com.example.veeru.musical_instruments;

import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

public class Piano2Activity extends AppCompatActivity {




    private Button A, B, C, D, E, F, G;
    private Button AA, BB, CC, DD, EE;
    public SoundPool soundpool;
    public  int Sound_A, Sound_B , Sound_C, Sound_D, Sound_E, Sound_F, Sound_G,Sound_AA, Sound_BB, Sound_CC, Sound_DD, Sound_EE;
    private boolean Sustain;

    @Override
    protected void onStop() {
        soundpool.release();
        soundpool=null;
        super.onStop();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_piano1);

        Button p1b1= (Button) findViewById(R.id.p1btn1);
        Button p1b2= (Button) findViewById(R.id.p1btn2);
        Button p1b3= (Button) findViewById(R.id.p1btn3);




        A = (Button) findViewById(R.id.A);
        B = (Button) findViewById(R.id.B);
        C = (Button) findViewById(R.id.C);
        D = (Button) findViewById(R.id.D);
        E = (Button) findViewById(R.id.E);
        F = (Button) findViewById(R.id.F);
        G = (Button) findViewById(R.id.G);

        AA = (Button) findViewById(R.id.AA);
        BB = (Button) findViewById(R.id.BB);
        CC = (Button) findViewById(R.id.CC);
        DD = (Button) findViewById(R.id.DD);
        EE = (Button) findViewById(R.id.EE);



        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            soundpool = new SoundPool.Builder().setMaxStreams(5).build();
        } else {
            soundpool = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        }




        Sound_A = soundpool.load(this, R.raw.d3, 1);
        Sound_B = soundpool.load(this, R.raw.d3, 1);
        Sound_C = soundpool.load(this, R.raw.e3, 1);
        Sound_D = soundpool.load(this, R.raw.f3, 1);
        Sound_E = soundpool.load(this, R.raw.g3, 1);
        Sound_F = soundpool.load(this, R.raw.a3, 1);
        Sound_G = soundpool.load(this, R.raw.b3, 1);

        Sound_AA = soundpool.load(this, R.raw.c3m, 1);
        Sound_BB = soundpool.load(this, R.raw.d3m, 1);
        Sound_CC = soundpool.load(this, R.raw.f2m, 1);
        Sound_DD = soundpool.load(this, R.raw.g3m, 1);
        Sound_EE = soundpool.load(this, R.raw.a3m, 1);



        A.setOnTouchListener(new View.OnTouchListener() {

            boolean keyIsPressed = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // Finger started pressing --> play sound in loop mode
                        soundpool.play(Sound_A, 1, 1, 0, 0, 1);
                        keyIsPressed = true;
                        A.setBackgroundResource(R.drawable.keyylp);;
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        // Finger released --> stop playback
                        A.setBackgroundResource(R.drawable.keyyy);


                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_A);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        // Finger released --> stop playback
                        A.setBackgroundResource(R.drawable.keyyy);

                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_A);
                        }
                        break;



                    case MotionEvent.ACTION_MOVE:
                        // Finger is moving on key --> start playback if the key is not already played
                        if(!keyIsPressed) {
                            soundpool.play(Sound_A, 1, 1, 0, 0, 1);
                            keyIsPressed = true;
                            A.setBackgroundResource(R.drawable.keyylp);
                        }
                }
                return true;
            }
        });
        B.setOnTouchListener(new View.OnTouchListener() {

            boolean keyIsPressed = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // Finger started pressing --> play sound in loop mode
                        soundpool.play(Sound_B, 1, 1, 0, 0, 1);
                        keyIsPressed = true;
                        B.setBackgroundResource(R.drawable.krycp);
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        // Finger released --> stop playback
                        B.setBackgroundResource(R.drawable.whitemkey);


                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_B);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        // Finger released --> stop playback
                        B.setBackgroundResource(R.drawable.whitemkey);

                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_B);
                        }
                        break;



                    case MotionEvent.ACTION_MOVE:
                        // Finger is moving on key --> start playback if the key is not already played
                        if(!keyIsPressed) {
                            soundpool.play(Sound_B, 1, 1, 0, 0, 1);
                            keyIsPressed = true;
                            B.setBackgroundResource(R.drawable.krycp);
                        }
                }
                return true;
            }
        });
        C.setOnTouchListener(new View.OnTouchListener() {

            boolean keyIsPressed = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // Finger started pressing --> play sound in loop mode
                        soundpool.play(Sound_C, 1, 1, 0, 0, 1);
                        keyIsPressed = true;
                        C.setBackgroundResource(R.drawable.keyrp);
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        // Finger released --> stop playback
                        C.setBackgroundResource(R.drawable.whiteskey);


                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_C);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        // Finger released --> stop playback
                        C.setBackgroundResource(R.drawable.whiteskey);

                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_C);
                        }
                        break;



                    case MotionEvent.ACTION_MOVE:
                        // Finger is moving on key --> start playback if the key is not already played
                        if(!keyIsPressed) {
                            soundpool.play(Sound_C, 1, 1, 0, 0, 1);
                            keyIsPressed = true;
                            C.setBackgroundResource(R.drawable.keyrp);
                        }
                }
                return true;
            }
        });
        D.setOnTouchListener(new View.OnTouchListener() {

            boolean keyIsPressed = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // Finger started pressing --> play sound in loop mode
                        soundpool.play(Sound_D, 1, 1, 0, 0, 1);
                        keyIsPressed = true;
                        D.setBackgroundResource(R.drawable.keyylp);
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        // Finger released --> stop playback
                        D.setBackgroundResource(R.drawable.keyyy);


                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_D);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        // Finger released --> stop playback
                        D.setBackgroundResource(R.drawable.keyyy);

                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_D);
                        }
                        break;



                    case MotionEvent.ACTION_MOVE:
                        // Finger is moving on key --> start playback if the key is not already played
                        if(!keyIsPressed) {
                            soundpool.play(Sound_D, 1, 1, 0, 0, 1);
                            keyIsPressed = true;
                            D.setBackgroundResource(R.drawable.keyylp);
                        }
                }
                return true;
            }
        });;
        E.setOnTouchListener(new View.OnTouchListener() {

            boolean keyIsPressed = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // Finger started pressing --> play sound in loop mode
                        soundpool.play(Sound_E, 1, 1, 0, 0, 1);
                        keyIsPressed = true;
                        E.setBackgroundResource(R.drawable.krycp);
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        // Finger released --> stop playback
                        E.setBackgroundResource(R.drawable.whitemkey);


                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_E);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        // Finger released --> stop playback
                        E.setBackgroundResource(R.drawable.whitemkey);

                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_E);
                        }
                        break;



                    case MotionEvent.ACTION_MOVE:
                        // Finger is moving on key --> start playback if the key is not already played
                        if(!keyIsPressed) {
                            soundpool.play(Sound_E, 1, 1, 0, 0, 1);
                            keyIsPressed = true;
                            E.setBackgroundResource(R.drawable.krycp);
                        }
                }
                return true;
            }
        });;
        F.setOnTouchListener(new View.OnTouchListener() {

            boolean keyIsPressed = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // Finger started pressing --> play sound in loop mode
                        soundpool.play(Sound_F, 1, 1, 0, 0, 1);
                        keyIsPressed = true;
                        F.setBackgroundResource(R.drawable.krycp);
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        // Finger released --> stop playback
                        E.setBackgroundResource(R.drawable.whitemkey);


                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_E);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        // Finger released --> stop playback
                        F.setBackgroundResource(R.drawable.whitemkey);

                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_F);
                        }
                        break;



                    case MotionEvent.ACTION_MOVE:
                        // Finger is moving on key --> start playback if the key is not already played
                        if(!keyIsPressed) {
                            soundpool.play(Sound_F, 1, 1, 0, 0, 1);
                            keyIsPressed = true;
                            F.setBackgroundResource(R.drawable.krycp);
                        }
                }
                return true;
            }
        });
        G.setOnTouchListener(new View.OnTouchListener() {

            boolean keyIsPressed = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // Finger started pressing --> play sound in loop mode
                        soundpool.play(Sound_B, 1, 1, 0, 0, 1);
                        keyIsPressed = true;
                        G.setBackgroundResource(R.drawable.keyrp);
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        // Finger released --> stop playback
                        G.setBackgroundResource(R.drawable.whiteskey);


                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_G);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        // Finger released --> stop playback
                        G.setBackgroundResource(R.drawable.whiteskey);

                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_G);
                        }
                        break;



                    case MotionEvent.ACTION_MOVE:
                        // Finger is moving on key --> start playback if the key is not already played
                        if(!keyIsPressed) {
                            soundpool.play(Sound_G, 1, 1, 0, 0, 1);
                            keyIsPressed = true;
                            G.setBackgroundResource(R.drawable.keyrp);
                        }
                }
                return true;
            }
        });


        AA. setOnTouchListener(new View.OnTouchListener() {

            boolean keyIsPressed = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // Finger started pressing --> play sound in loop mode
                        soundpool.play(Sound_AA, 1, 1, 0, 0, 1);
                        keyIsPressed = true;
                        AA.setBackgroundResource(R.drawable.blackeyt);
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        // Finger released --> stop playback
                        AA.setBackgroundResource(R.drawable.blackey);


                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_AA);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        // Finger released --> stop playback
                        AA.setBackgroundResource(R.drawable.blackey);

                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_AA);
                        }
                        break;



                    case MotionEvent.ACTION_MOVE:
                        // Finger is moving on key --> start playback if the key is not already played
                        if(!keyIsPressed) {
                            soundpool.play(Sound_AA, 1, 1, 0, 0, 1);
                            keyIsPressed = true;
                            AA.setBackgroundResource(R.drawable.blackeyt);
                        }
                }
                return true;
            }
        });
        BB.setOnTouchListener(new View.OnTouchListener() {

            boolean keyIsPressed = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // Finger started pressing --> play sound in loop mode
                        soundpool.play(Sound_BB, 1, 1, 0, 0, 1);
                        keyIsPressed = true;
                        BB.setBackgroundResource(R.drawable.blackeyt);
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        // Finger released --> stop playback
                        BB.setBackgroundResource(R.drawable.blackey);


                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_BB);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        // Finger released --> stop playback
                        BB.setBackgroundResource(R.drawable.blackey);

                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_BB);
                        }
                        break;



                    case MotionEvent.ACTION_MOVE:
                        // Finger is moving on key --> start playback if the key is not already played
                        if(!keyIsPressed) {
                            soundpool.play(Sound_BB, 1, 1, 0, 0, 1);
                            keyIsPressed = true;
                            BB.setBackgroundResource(R.drawable.blackeyt);
                        }
                }
                return true;
            }
        });
        CC.setOnTouchListener(new View.OnTouchListener() {

            boolean keyIsPressed = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // Finger started pressing --> play sound in loop mode
                        soundpool.play(Sound_CC, 1, 1, 0, 0, 1);
                        keyIsPressed = true;
                        CC.setBackgroundResource(R.drawable.blackeyt);
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        // Finger released --> stop playback
                        CC.setBackgroundResource(R.drawable.blackey);


                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_CC);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        // Finger released --> stop playback
                        CC.setBackgroundResource(R.drawable.blackey);

                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_CC);
                        }
                        break;



                    case MotionEvent.ACTION_MOVE:
                        // Finger is moving on key --> start playback if the key is not already played
                        if(!keyIsPressed) {
                            soundpool.play(Sound_CC, 1, 1, 0, 0, 1);
                            keyIsPressed = true;
                            CC.setBackgroundResource(R.drawable.blackeyt);
                        }
                }
                return true;
            }
        });
        DD.setOnTouchListener(new View.OnTouchListener() {

            boolean keyIsPressed = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // Finger started pressing --> play sound in loop mode
                        soundpool.play(Sound_DD, 1, 1, 0, 0, 1);
                        keyIsPressed = true;
                        DD.setBackgroundResource(R.drawable.blackeyt);
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        // Finger released --> stop playback
                        DD.setBackgroundResource(R.drawable.blackey);


                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_DD);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        // Finger released --> stop playback
                        DD.setBackgroundResource(R.drawable.blackey);

                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_DD);
                        }
                        break;



                    case MotionEvent.ACTION_MOVE:
                        // Finger is moving on key --> start playback if the key is not already played
                        if(!keyIsPressed) {
                            soundpool.play(Sound_DD, 1, 1, 0, 0, 1);
                            keyIsPressed = true;
                            DD.setBackgroundResource(R.drawable.blackeyt);
                        }
                }
                return true;
            }
        });
        EE.setOnTouchListener(new View.OnTouchListener() {

            boolean keyIsPressed = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // Finger started pressing --> play sound in loop mode
                        soundpool.play(Sound_EE, 1, 1, 0, 0, 1);
                        keyIsPressed = true;
                        EE.setBackgroundResource(R.drawable.blackeyt);
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        // Finger released --> stop playback
                        EE.setBackgroundResource(R.drawable.blackey);


                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_EE);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        // Finger released --> stop playback
                        EE.setBackgroundResource(R.drawable.blackey);

                        if(!Sustain){
                            keyIsPressed = false;
                            soundpool.stop(Sound_EE);
                        }
                        break;



                    case MotionEvent.ACTION_MOVE:
                        // Finger is moving on key --> start playback if the key is not already played
                        if(!keyIsPressed) {
                            soundpool.play(Sound_EE, 1, 1, 0, 0, 1);
                            keyIsPressed = true;
                            EE.setBackgroundResource(R.drawable.blackeyt);
                        }
                }
                return true;
            }
        });
        p1b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(Piano2Activity.this, Piano1Activity.class);
                startActivity(intent);
                finish();
            }
        });



        p1b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(Piano2Activity.this, Piano2Activity.class);
                startActivity(intent);

            }
        });



        p1b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(Piano2Activity.this, Piano3Activity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}

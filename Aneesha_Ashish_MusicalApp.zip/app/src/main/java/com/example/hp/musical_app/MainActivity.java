package com.example.hp.musical_app;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    private RadioButton rbPiano;
    private RadioButton rbGuitar;
    private RadioButton rbTabla;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rbPiano = (RadioButton) findViewById(R.id.rbPiano);
        rbGuitar = (RadioButton) findViewById(R.id.rbGuitar);
        rbTabla = (RadioButton) findViewById(R.id.rbTabla);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (rbPiano.isChecked()) {
                    Intent i = new Intent(MainActivity.this, Piano_Activity.class);
                    startActivity(i);

                } else if (rbGuitar.isChecked()) {
                    Intent i = new Intent(MainActivity.this, Guitar_Activity.class);
                    startActivity(i);

                } else if (rbTabla.isChecked()) {
                    Intent i = new Intent(MainActivity.this, Tabla_Activity.class);
                    startActivity(i);

                }
            }
        });
    }
}



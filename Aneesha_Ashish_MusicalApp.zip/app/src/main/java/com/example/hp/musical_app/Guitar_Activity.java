package com.example.hp.musical_app;

import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;



public class Guitar_Activity extends AppCompatActivity  {


    private SoundPool soundPool;
    private int sound_btn1,sound_btn2,sound_btn3,sound_btn4,sound_btn5,sound_btn6;
    private Button btn1;
    private Button btn2;
    private Button btn3;
    private Button btn5;
    private Button btn4;
    private Button btn6;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guitar_);

        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        btn5 = (Button) findViewById(R.id.btn5);
        btn6 = (Button) findViewById(R.id.btn6);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            soundPool = new SoundPool.Builder().setMaxStreams(10).build();
        } else {
            soundPool = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
        }

        sound_btn1 = soundPool.load(this, R.raw.g1, 1);
        sound_btn2 = soundPool.load(this, R.raw.g2, 1);
        sound_btn3 = soundPool.load(this, R.raw.g3, 1);
        sound_btn4 = soundPool.load(this, R.raw.g4, 1);
        sound_btn5 = soundPool.load(this, R.raw.g5, 1);
        sound_btn6 = soundPool.load(this, R.raw.g6, 1);

        btn1.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                soundPool.play(sound_btn1,1,1,0,0,1);
                return false;


            }
        });

        btn2.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                soundPool.play(sound_btn2,1,1,0,0,1);
                return false;
            }
        });
        btn3.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                soundPool.play(sound_btn3, 1, 1, 0, 0, 1);
                return false;
            }
        });

        btn4.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                soundPool.play(sound_btn4, 1, 1, 0, 0, 1);
                return false;
            }
        });
        btn5.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                soundPool.play(sound_btn5,1,1,0,0,1);
                return false;
            }
        });
        btn6.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                soundPool.play(sound_btn6,1,1,0,0,1);
                return false;
            }
        });


    }


    }


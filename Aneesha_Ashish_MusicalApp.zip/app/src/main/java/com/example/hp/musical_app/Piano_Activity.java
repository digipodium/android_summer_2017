package com.example.hp.musical_app;

import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Piano_Activity extends AppCompatActivity {

    Button btnA,btnB,btnC,btnD,btnE,btnF,btnG,btnH,btnI,btnJ,btnK
            ,btnL,btnM,btnN,btnO,btnP,btnQ;


    private SoundPool soundPool;
    private int sound_btnA, sound_btnB, sound_btnC,sound_btnD,sound_btnE,sound_btnF,sound_btnG,sound_btnH,
            sound_btnI,sound_btnJ,sound_btnK,sound_btnL,sound_btnM,sound_btnN,sound_btnO,sound_btnP,sound_btnQ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_piano_);

        btnA = (Button) findViewById(R.id.btnA);
        btnB = (Button) findViewById(R.id.btnB);
        btnC = (Button) findViewById(R.id.btnC);
        btnD = (Button) findViewById(R.id.btnD);
        btnE = (Button) findViewById(R.id.btnE);
        btnF = (Button) findViewById(R.id.btnF);
        btnG = (Button) findViewById(R.id.btnG);
        btnH = (Button) findViewById(R.id.btnH);
        btnI = (Button) findViewById(R.id.btnI);
        btnJ = (Button) findViewById(R.id.btnJ);
        btnK = (Button) findViewById(R.id.btnK);
        btnL = (Button) findViewById(R.id.btnL);
        btnM = (Button) findViewById(R.id.btnM);
        btnN = (Button) findViewById(R.id.btnN);
        btnO = (Button) findViewById(R.id.btnO);
        btnP = (Button) findViewById(R.id.btnP);
        btnQ = (Button) findViewById(R.id.btnQ);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            soundPool = new SoundPool.Builder().setMaxStreams(10).build();
        } else {
            soundPool = new SoundPool(10, AudioManager.STREAM_MUSIC,0);
        }

        sound_btnA = soundPool.load(this,R.raw.a,1);
        sound_btnB = soundPool.load(this,R.raw.b,1);
        sound_btnC = soundPool.load(this,R.raw.c,1);
        sound_btnD = soundPool.load(this,R.raw.d,1);
        sound_btnE = soundPool.load(this,R.raw.e,1);
        sound_btnF = soundPool.load(this,R.raw.f,1);
        sound_btnG = soundPool.load(this,R.raw.g,1);
        sound_btnH = soundPool.load(this,R.raw.h,1);
        sound_btnI = soundPool.load(this,R.raw.i,1);
        sound_btnJ = soundPool.load(this,R.raw.j,1);
        sound_btnK = soundPool.load(this,R.raw.k,1);
        sound_btnL = soundPool.load(this,R.raw.l,1);
        sound_btnM = soundPool.load(this,R.raw.m,1);
        sound_btnN = soundPool.load(this,R.raw.n,1);
        sound_btnO = soundPool.load(this,R.raw.o,1);
        sound_btnP = soundPool.load(this,R.raw.p,1);
        sound_btnQ = soundPool.load(this,R.raw.q,1);

        btnA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnA,1,1,0,0,1);
            }
        });

        btnB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnB,1,1,0,0,1);
            }
        });

        btnC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnC,1,1,0,0,1);
            }
        });
        btnD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnD,1,1,0,0,1);
            }
        });

        btnE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnE,1,1,0,0,1);
            }
        });

        btnF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnF,1,1,0,0,1);
            }
        });

        btnG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnG,1,1,0,0,1);
            }
        });

        btnH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnH,1,1,0,0,1);
            }
        });

        btnI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnI,1,1,0,0,1);
            }
        });

        btnJ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnJ,1,1,0,0,1);
            }
        });
        btnK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnK,1,1,0,0,1);
            }
        });
        btnL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnL,1,1,0,0,1);
            }
        });
        btnM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnM,1,1,0,0,1);
            }
        });
        btnN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnN,1,1,0,0,1);
            }
        });
        btnO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnO,1,1,0,0,1);
            }
        });
        btnP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnP,1,1,0,0,1);
            }
        });

        btnQ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnQ,1,1,0,0,1);
            }
        });



    }
    }


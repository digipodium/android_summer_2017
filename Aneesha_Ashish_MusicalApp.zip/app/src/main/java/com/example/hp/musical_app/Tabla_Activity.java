package com.example.hp.musical_app;

import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tabla_Activity extends AppCompatActivity {
Button btna,btnb,btnc,btnd,btne,btnf;
    private SoundPool soundPool;
    private int sound_btna,sound_btnb,sound_btnc,sound_btnd,sound_btne,sound_btnf;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tabla_);

        btna = (Button) findViewById(R.id.btna);
        btnb = (Button) findViewById(R.id.btnb);
        btnc = (Button) findViewById(R.id.btnc);
        btnd = (Button) findViewById(R.id.btnd);
        btne = (Button) findViewById(R.id.btne);
        btnf = (Button) findViewById(R.id.btnf);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            soundPool = new SoundPool.Builder().setMaxStreams(10).build();
        } else {
            soundPool = new SoundPool(10, AudioManager.STREAM_MUSIC,0);
        }

        sound_btna = soundPool.load(this,R.raw.t1,1);
        sound_btnb = soundPool.load(this,R.raw.t2,1);
        sound_btnc = soundPool.load(this,R.raw.t3,1);
        sound_btnd = soundPool.load(this,R.raw.t4,1);
        sound_btne = soundPool.load(this,R.raw.t5,1);
        sound_btnf = soundPool.load(this,R.raw.t6,1);

        btna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btna,1,1,0,0,1);
            }
        });

        btnb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnb,1,1,0,0,1);
            }
        });

        btnc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnc,1,1,0,0,1);
            }
        });
        btnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnd,1,1,0,0,1);
            }
        });

        btne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btne,1,1,0,0,1);
            }
        });

        btnf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(sound_btnf,1,1,0,0,1);
            }
        });



    }
}

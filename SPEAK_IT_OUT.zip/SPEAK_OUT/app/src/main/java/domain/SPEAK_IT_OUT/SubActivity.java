package domain.SPEAK_IT_OUT;
import java.util.Locale;
import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Toast;

public class SubActivity extends Activity implements
        TextToSpeech.OnInitListener {
    private TextToSpeech tts;
    private Button btnSpeak;
    private EditText EtText;
    private float selectedPitch=1f;
    private float selectedSpeed=1f;
    private SeekBar seekPitch,seekSpeed;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        tts = new TextToSpeech(this, this);
        btnSpeak = (Button)findViewById(R.id.BtnSpeak);
        EtText = (EditText)findViewById(R.id.EtText);
        seekPitch=(SeekBar)findViewById(R.id.seekPitch);
        seekSpeed=(SeekBar)findViewById(R.id.seekSpeed);

        btnSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                speakOut();
            }
        });
        seekPitch.setThumbOffset(5);
        seekPitch.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                selectedPitch=((float )i)/100f;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        seekSpeed.setThumbOffset(5);
        seekSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                selectedSpeed=((float)i)/100f;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
tts.setLanguage(Locale.UK);
        }
    }
    //method to speak text
    private void speakOut() {

        String text = EtText.getText().toString();

            //speak given text
            tts.setPitch(selectedPitch);
            tts.setSpeechRate(selectedSpeed);
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
            Toast.makeText(this, "Device is speaking", Toast.LENGTH_SHORT).show();

    }
}
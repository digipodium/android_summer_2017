package trainedge.womensafety;

import android.Manifest;
import android.app.ListActivity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import static android.R.attr.mode;
import static android.R.attr.switchMinWidth;

public class ShowContactList extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private ListView contact_list;
    ArrayList<String> StoreContacts;
    public ArrayList<String> SelectedContacts=new ArrayList<String>();
    private boolean flag=true;
    private SharedPreferences tc;
    private SharedPreferences app_run;
    private TextView tvUserName;
    private String name;
    int c=0;
    int cnt=0;
    private CustomAdapter adapter;
    Context context;
    private Vibrator vibrator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_contact_list);
        vibrator = (Vibrator)this.getSystemService(this.VIBRATOR_SERVICE);
        tvUserName=(TextView)findViewById(R.id.tvUserName);

        Intent receivedIntent=getIntent();
        name = receivedIntent.getStringExtra("trainedge.womensafety.username");


        contact_list = (ListView)findViewById(R.id.contactList);

        SharedPreferences pref=getSharedPreferences("account",MODE_PRIVATE);
        String n=pref.getString("username","");
        tvUserName.setText("Welcome "+ n +", select your trusted contacts...");

        //handlePermission();
        getContacts();

        adapter = new CustomAdapter(this,0,StoreContacts);
        //contact_list.setItemChecked(1,true);
        contact_list.setAdapter(adapter);
        contact_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(ShowContactList.this, "Long press to select", Toast.LENGTH_SHORT).show();
            }
        });
        contact_list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                vibrator.vibrate(2000);
                return true;
            }
        });
        contact_list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        contact_list.setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {
            @Override
            public void onItemCheckedStateChanged(ActionMode actionMode, int i, long l, boolean b) {
                if(b==true) {
                    c = c + 1;
                    SelectedContacts.add(StoreContacts.get(i));
                }else if(b==false){
                    c=c-1;
                    SelectedContacts.remove((StoreContacts.get(i)));
                }
                if(c==1){
                    actionMode.setTitle("1 contact selected");
                }
                else if (c==0){
                    actionMode.setTitle("");
                }
                    else {
                    actionMode.setTitle(c + "  contacts selected");
                }
            }

            @Override
            public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
                MenuInflater inflater=actionMode.getMenuInflater();
                inflater.inflate(R.menu.list_select_menu,menu);
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
                switch(menuItem.getItemId()){
                    case R.id.done:
                        vibrator.vibrate(100);
                        if(SelectedContacts.size()>5){
                            Toast.makeText(ShowContactList.this, "You cannot select more than 5 trusted contacts", Toast.LENGTH_SHORT).show();
                        }
                        else if(SelectedContacts.size()<2){
                            Toast.makeText(ShowContactList.this, "Please select atleast 2 trusted contacts", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            tc = getSharedPreferences("trustedContacts",MODE_PRIVATE);
                            SharedPreferences.Editor editor = tc.edit();
                            for(int i=0;i<SelectedContacts.size();i++){
                                editor.putString(i+"",SelectedContacts.get(i));
                                editor.apply();
                            }
                            editor.putString("num_contacts",""+SelectedContacts.size());
                            editor.apply();
                            Toast.makeText(ShowContactList.this, "Successfully added your trusted contacts", Toast.LENGTH_SHORT).show();

                            app_run=getSharedPreferences("appRunCount",MODE_PRIVATE);
                            SharedPreferences.Editor editor1=app_run.edit();
                            editor1.putString("appRunNumber","notFirstTimeRun");
                            editor1.apply();

                            Intent safeActivity=new Intent(ShowContactList.this,SafeActivity.class);
                            safeActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(safeActivity);
                            finish();
                            c=0;
                            actionMode.finish();
                            return true;
                        }
                        //break;
                    default:
                        return  false;
                }
                //return false;
            }

            @Override
            public void onDestroyActionMode(ActionMode actionMode) {

            }
        });
        //contact_list.setOnItemClickListener(this);
    }

    private void handlePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!= PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},12);
            }
            else{
                getContacts();
            }
        }
        else{
            getContacts();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode==12){
            for(int i=1;i<permissions.length;i++){
                if(grantResults[i]==PackageManager.PERMISSION_GRANTED){
                    flag=true;
                }
                else{
                    Toast.makeText(this, "This app wont work without your permission of" + permissions[i], Toast.LENGTH_SHORT).show();
                    flag=false;
                }
            }
            if(flag==true){
                getContacts();
            }
            else {
                handlePermission();
            }
        }
    }

    private void getContacts() {
        StoreContacts=new ArrayList<>();
        //contactList=new ArrayList<>();
        //Cursor phones = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,null,null, null);
        //int id=1;
        /*while (phones.moveToNext())
        {
            String name=phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            String phoneNumber = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            contactList.add(new ContactsModel(name, phoneNumber,id));
            id++;
            //Toast.makeText(getApplicationContext(),name+" "+phoneNumber, Toast.LENGTH_LONG).show();
        }
        phones.close();*/

        ContentResolver cr = getContentResolver();
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);

        if (cur.getCount() > 0) {
            while (cur.moveToNext()) {
                int id=1;
                String id1 = cur.getString(cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone._ID));
                String name = cur.getString(cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));

                if (cur.getInt(cur.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                    Cursor pCur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = ?", new String[]{id1}, null);
                    while (pCur.moveToNext()) {
                        String phoneNo = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        phoneNo=phoneNo.replaceAll("\\s","");
                        /*Toast.makeText(this, "Name: " + name
                                + ", Phone No: " + phoneNo, Toast.LENGTH_SHORT).show();*/
                        StoreContacts.add(name+":"+phoneNo);
                    }
                    pCur.close();
                }
            }
            cur.close();
        }
        //Collections.sort(contactList);
        Set<String> contactSet=new HashSet<>();
        contactSet.addAll(StoreContacts);
        StoreContacts.clear();
        StoreContacts.addAll(contactSet);

        Collections.sort(StoreContacts,new stringComparator());

    }

    int count=0;
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

        //getListView().setItemChecked(i,true);
        String str=StoreContacts.get(i);
        if(SelectedContacts.contains(str)){
            SelectedContacts.remove(str);
            count--;
            Toast.makeText(this,""+count+""+SelectedContacts.size(), Toast.LENGTH_SHORT).show();
        }
        else{
            SelectedContacts.add(str);
            count++;
            Toast.makeText(this,""+count+""+SelectedContacts.size(), Toast.LENGTH_SHORT).show();
        }
        //String item = ((TextView)view).getText().toString()

    }
}

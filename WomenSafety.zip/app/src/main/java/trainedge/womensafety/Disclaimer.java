package trainedge.womensafety;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Disclaimer extends AppCompatActivity {

    private TextView tvDisc;
    private TextView tvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disclaimer);
        tvDisc=(TextView)findViewById(R.id.tvDisc);
        tvBack=(TextView)findViewById(R.id.tvBack);
        tvDisc.setText("Whether it be lonely walk or late night homecoming, whether it be stalkers on the trail or some bizzare looks from strangers, Security+ app is always with you\n"+
        "The app has been basically developed for women so that their close friends and relatives may get informed if they fall in " +
                "some danger while returning from offices etc at late night,or falling a victim of any stranger at some lonely street. The app requires the user to select atleast 2 and atmost 5 trusted " +
                "contacts who get the user's location at the single click of the user if their is some kind of danger.\n" +
                "But the app at the same time can be used by anyone for their safety.");

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent home=new Intent(Disclaimer.this,MainActivity.class);
                home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(home);
                finish();
            }
        });
    }
}

package trainedge.womensafety;

import java.util.Comparator;

/**
 * Created by hppc on 7/25/2017.
 */

public class stringComparator implements Comparator {
    @Override
    public int compare(Object o, Object t1) {
        String s1=(String )o;
        String s2=(String )t1;
        s1=s1.toLowerCase();
        s2=s2.toLowerCase();
        return(s1.compareTo(s2));
    }
}

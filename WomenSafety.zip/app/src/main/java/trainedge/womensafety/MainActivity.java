package trainedge.womensafety;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Vibrator;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TranslateAnimation moveBottomtoTop;
    private Handler handler;
    private ImageView logo;
    public static float x1;
    public static float y1;
    private Button btnNext;
    public static float newy;
    private SharedPreferences pref;
    private boolean flag=false;
    private SharedPreferences app_run;
    private EditText etName;
    private TextView tvInstruct;
    private ProgressBar progressBar;
    private TextView tvProgressStatus;
    Context context;
    private Vibrator vibrator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        handlePermission();
        app_run = getSharedPreferences("appRunCount",MODE_PRIVATE);
        String code=app_run.getString("appRunNumber","");
        if(code.equals("notFirstTimeRun")){
            Intent safe=new Intent(this,SafeActivity.class);
            safe.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(safe);
            finish();
        }
        else{
            processRemainingPart();
        }
    }

    private void processRemainingPart() {
        logo = (ImageView)findViewById(R.id.logo1);
        etName=(EditText)findViewById(R.id.etName);
        btnNext=(Button)findViewById(R.id.btnNext);
        tvInstruct=(TextView)findViewById(R.id.tvInstruct);
        tvProgressStatus=(TextView)findViewById(R.id.tvProgressStatus);
        progressBar=(ProgressBar)findViewById(R.id.progressBar);

        tvInstruct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent instruction=new Intent(MainActivity.this,Instructions.class);
                startActivity(instruction);
            }
        });

        vibrator = (Vibrator)this.getSystemService(this.VIBRATOR_SERVICE);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name=etName.getText().toString();
                if(name.isEmpty()){
                    etName.setError("Please enter your name");
                    vibrator.vibrate(300);
                    return;
                }
                //progressBar.setVisibility(View.VISIBLE);
                //tvProgressStatus.setVisibility(View.VISIBLE);
                Toast.makeText(MainActivity.this, "Fetching Your Contacts...", Toast.LENGTH_SHORT).show();
                vibrator.vibrate(100);
                SharedPreferences pref=getSharedPreferences("account",MODE_PRIVATE);
                SharedPreferences.Editor editor=pref.edit();
                editor.putString("username",name);
                editor.apply();

                        //progressBar.setVisibility(View.VISIBLE);

                Intent i=new Intent(MainActivity.this,ShowContactList.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
                finish();


            }
        });

        etName.setVisibility(View.INVISIBLE);
        btnNext.setVisibility(View.INVISIBLE);
        tvInstruct.setVisibility(View.INVISIBLE);
        tvProgressStatus.setVisibility(View.INVISIBLE);
        progressBar.setVisibility(View.GONE);

        Animation myFadeInAnimation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fadein);
        logo.startAnimation(myFadeInAnimation);
        int[] posXY = new int[2];
        logo.getLocationOnScreen(posXY);
        int x = posXY[0];
        int y = posXY[1];
        x1 = (float) x;
        y1 = (float) y;
        newy=y1-300;

        handler=new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //moveBottomtoTop = new TranslateAnimation(imageView.getX(), imageView.getX(), imageView.getY(), imageView.getY()-500);
                moveBottomtoTop = new TranslateAnimation(x1, x1, y1, y1 -250);
                moveBottomtoTop.setDuration(2000);
                moveBottomtoTop.setFillAfter(true);
                logo.startAnimation(moveBottomtoTop);
            }
        },3000);


        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                etName.setVisibility(View.VISIBLE);
                btnNext.setVisibility(View.VISIBLE);
                btnNext.setVisibility(View.VISIBLE);
                tvInstruct.setVisibility(View.VISIBLE);


                Animation myFadeInAnimation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fadein_text);
                etName.startAnimation(myFadeInAnimation);
                btnNext.startAnimation(myFadeInAnimation);
                tvInstruct.startAnimation(myFadeInAnimation);
            }
        },4000);
    }

    private void handlePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if((checkSelfPermission(Manifest.permission.READ_CONTACTS)!= PackageManager.PERMISSION_GRANTED)
                    || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.INTERNET)!= PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.VIBRATE)!= PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{Manifest.permission.READ_CONTACTS,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.SEND_SMS,
                        Manifest.permission.INTERNET,
                        Manifest.permission.VIBRATE},12);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode==12){
            for(int i=1;i<permissions.length;i++){
                if(grantResults[i]==PackageManager.PERMISSION_GRANTED){
                    flag=true;
                }
                else{
                    Toast.makeText(this, "This app wont work without your permission of" + permissions[i], Toast.LENGTH_SHORT).show();
                    flag=false;
                }
            }
            if(flag==false){
                handlePermission();
            }
        }
    }
}

package trainedge.womensafety;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class ViewContacts extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_contacts);

        RecyclerView recycle=(RecyclerView)findViewById(R.id.recycle);
        LinearLayoutManager manager=new LinearLayoutManager(this);
        ArrayList<String> viewContacts=SafeActivity.getContacts;

        ContactAdapter  adapter=new ContactAdapter(viewContacts,this);
        recycle.setLayoutManager(manager);
        recycle.setAdapter(adapter);
    }
}

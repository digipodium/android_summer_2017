package trainedge.womensafety;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

public class SafeActivity extends AppCompatActivity implements OnSuccessListener<Location> {

    private boolean flag = false;
    private double latitude;
    private double longitude;
    private String subLocality;
    private String locality;
    private String country;
    private String address;
    private String loc;
    public static  ArrayList<String> getContacts;
    private SharedPreferences tc;
    LocationManager locationManager;
    private int f=0;
    private ProgressBar progress;
    private Button btnSend;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_safe);
        SharedPreferences pref=getSharedPreferences("account",MODE_PRIVATE);
        final String username = pref.getString("username", "");

        //handlePermission();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        /*if(locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)){
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                    Geocoder geocoder = new Geocoder(SafeActivity.this);
                    try {
                        List<Address> addressList = geocoder.getFromLocation(latitude, longitude, 1);
                        subLocality = addressList.get(0).getSubLocality();
                        locality = addressList.get(0).getLocality();
                        country = addressList.get(0).getCountryName();
                        address = addressList.get(0).getAddressLine(0);
                        loc = address + ", " + subLocality + ", " + locality + ", " + country;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onStatusChanged(String s, int i, Bundle bundle) {

                }

                @Override
                public void onProviderEnabled(String s) {

                }

                @Override
                public void onProviderDisabled(String s) {

                }
            });
        }
        else if(locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                    Geocoder geocoder = new Geocoder(SafeActivity.this);
                    try {
                        List<Address> addressList = geocoder.getFromLocation(latitude, longitude, 1);
                        subLocality = addressList.get(0).getSubLocality();
                        locality = addressList.get(0).getLocality();
                        country = addressList.get(0).getCountryName();
                        address = addressList.get(0).getAddressLine(0);
                        loc = address + ", " + subLocality + ", " + locality + ", " + country;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onStatusChanged(String s, int i, Bundle bundle) {

                }

                @Override
                public void onProviderEnabled(String s) {

                }

                @Override
                public void onProviderDisabled(String s) {

                }
            });
        }*/

        setUpLocationServices();
        btnSend = (Button) findViewById(R.id.btnSend);
        progress=(ProgressBar)findViewById(R.id.progress);
        progress.setVisibility(View.INVISIBLE);

        tc = getSharedPreferences("trustedContacts", MODE_PRIVATE);
        String num = tc.getString("num_contacts", "");
        int n = Integer.parseInt(num);
        getContacts = new ArrayList<String>();
        for (int i = 0; i < n; i++) {
            String contact = tc.getString(i + "", "");
            getContacts.add(contact);
        }

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //setUpLocationServices();
                SmsManager sms = SmsManager.getDefault();
                for (int i = 0; i < getContacts.size(); i++) {
                    String contact = getContacts.get(i);
                    String str[] = contact.split(":");
                    String phnum = str[1];
                    if(f==0){
                        sms.sendTextMessage(phnum, null, "Hello, i am in an immediate danger, Please trace my location and save me as soon as possible\n" +
                                "-"+username, null, null);
                    }
                    else if(f==1){
                        sms.sendTextMessage(phnum, null, "Hello, i am in an immediate danger, my current location is-" + " " + loc
                                + ".\n" + "Please reach to me & save me as soon as possible.\n" +
                                "-"+username, null, null);
                    }
                }
                Toast.makeText(SafeActivity.this, "Message sent to " + getContacts.size() + " trusted contacts.", Toast.LENGTH_SHORT).show();
                /*SmsManager sms = SmsManager.getDefault();
                sms.sendTextMessage("8960717629", null,"Hello, i am in an immediate danger, my current location is-"+" "+ loc +".\n"+"Plz help me asap.", null, null);*/
            }
        });
    }

    private void handlePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if ((checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) ||
                    (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) ) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.READ_CONTACTS}, 11);
            } else {
                setUpLocationServices();
            }
        } else {
            setUpLocationServices();
        }
    }

    private void setUpLocationServices() {
        FusedLocationProviderClient client = new FusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED ){
            return;
        }
        client.getLastLocation().addOnSuccessListener(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 11) {

            for (int i = 1; i < permissions.length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    flag = true;
                } else {
                    Toast.makeText(this, "This app wont work without your permission of" + permissions[i], Toast.LENGTH_SHORT).show();
                    flag = false;
                }
            }
            if (flag == true) {
                setUpLocationServices();
            } else {
                handlePermission();
            }
        }
    }

    @Override
    public void onSuccess(Location location) {
        if (location != null) {
            latitude = location.getLatitude();
            longitude = location.getLongitude();
            LatLng l = new LatLng(latitude, longitude);
            Geocoder geocoder = new Geocoder(this);
            try {
                List<Address> addressList = geocoder.getFromLocation(latitude, longitude, 1);
                subLocality = addressList.get(0).getSubLocality();
                locality = addressList.get(0).getLocality();
                country = addressList.get(0).getCountryName();
                address = addressList.get(0).getAddressLine(0);
                loc = address + ", " + subLocality + ", " + locality + ", " + country;
                if(!(loc.equals(""))){
                    f=1;
                }
                else{
                    f=0;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        } else {
            Toast.makeText(this, "Please turn on both Internet & Location Services & restart the app", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_items,menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_change:
                /*SharedPreferences.Editor editor = tc.edit();
                editor.clear();
                editor.apply();*/
                //btnSend.setVisibility(View.INVISIBLE);
                //progress.setVisibility(View.VISIBLE);
                Toast.makeText(this, "Fetching Your Contacts...", Toast.LENGTH_SHORT).show();
                Intent change = new Intent(this, ShowContactList.class);
                startActivity(change);
                break;
            case R.id.action_disclaimer:
                Intent disc=new Intent(this,Disclaimer.class);
                startActivity(disc);
                break;
            case R.id.action_view:
                Intent view=new Intent(this,ViewContacts.class);
                startActivity(view);
                break;
            case R.id.action_instruct:
                Intent instruct=new Intent(this,Instructions.class);
                startActivity(instruct);
        }
        return true;
    }
}



package trainedge.womensafety;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

/**
 * Created by hppc on 7/25/2017.
 */

class ContactAdapter extends RecyclerView.Adapter<ContactHolder> {
    private ArrayList<String> list;
    Context context;
    public ContactAdapter(ArrayList<String> list, Context context)
    {
        this.list = list;
        this.context=context;
    }

    @Override
    public ContactHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_card,parent,false);
        ContactHolder holder=new ContactHolder(view,context,list);
        return holder;
    }

    @Override
    public void onBindViewHolder(final ContactHolder holder, int position) {
/*ContactsModel show=list.get(position);
        holder.tvName.setText(show.getName());
        holder.tvNumber.setText(show.getPhoneNumber());
        holder.tvId.setText(""+show.getId());*/
        final boolean isSelected=false;
        String contact=list.get(position);
        String str[]=contact.split(":");
        holder.tvName.setText(str[0]);
        holder.tvNumber.setText(str[1]);
        //holder.tvId.setText(""+list.size());
        /*holder.consLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(holder.isSelected==false){
                    holder.itemView.setBackgroundColor(holder.itemView.getResources().getColor(R.color.Red));
                    holder.isSelected=true;
                }
                else if(holder.isSelected==true){
                    holder.itemView.setBackgroundColor(holder.itemView.getResources().getColor(R.color.White));
                    holder.isSelected=false;
                }
            }
        });*/
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
    //private SparseBooleanArray selectedItems;
}

package trainedge.womensafety;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ShowContacts extends AppCompatActivity {

    //ArrayList<ContactsModel> contactList;
    private FloatingActionButton btnaddContacts;
    public static String contactNumbers[];
    ArrayList<String> StoreContacts;
    private boolean flag=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_contacts);

        handlePermission();

        RecyclerView recycler=(RecyclerView)findViewById(R.id.recycler);
        recycler.setHasFixedSize(true);
        LinearLayoutManager manager=new LinearLayoutManager(this);
        ContactAdapter  adapter=new ContactAdapter(StoreContacts,this);
        recycler.setLayoutManager(manager);
        recycler.setAdapter(adapter);

        btnaddContacts=(FloatingActionButton)findViewById(R.id.btnaddContacts);
        btnaddContacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ContactHolder.numHolder.size()<2){
                    Toast.makeText(ShowContacts.this, "Please select atleast 2 trusted contacts ", Toast.LENGTH_SHORT).show();
                }
                else if(ContactHolder.numHolder.size()>5){
                    Toast.makeText(ShowContacts.this, "You cannot select more than 5 contacts", Toast.LENGTH_SHORT).show();
                }
                else{
                    int i=0;
                    contactNumbers=new String[5];
                    for(int j=0;j<5;j++){
                        contactNumbers[j]="";
                    }
                    Iterator it=ContactHolder.numHolder.iterator();
                    while(it.hasNext()){
                        String phoneNumber=(String)it.next();
                        contactNumbers[i]=phoneNumber;
                    }
                    Toast.makeText(ShowContacts.this, "You have successfully added the trusted contacts", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(ShowContacts.this,SafeActivity.class);
                    startActivity(intent);
                }
            }
        });

    }

    private void handlePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!= PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},12);
            }
            else{
                getContacts();
            }
        }
        else{
            getContacts();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode==12){
            for(int i=1;i<permissions.length;i++){
                if(grantResults[i]==PackageManager.PERMISSION_GRANTED){
                    flag=true;
                }
                else{
                    Toast.makeText(this, "This app wont work without your permission of" + permissions[i], Toast.LENGTH_SHORT).show();
                    flag=false;
                }
            }
            if(flag==true){
                getContacts();
            }
            else {
                handlePermission();
            }
        }
    }


    private void getContacts() {

        StoreContacts=new ArrayList<>();
        //contactList=new ArrayList<>();
        //Cursor phones = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,null,null, null);
        //int id=1;
        /*while (phones.moveToNext())
        {
            String name=phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            String phoneNumber = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            contactList.add(new ContactsModel(name, phoneNumber,id));
            id++;
            //Toast.makeText(getApplicationContext(),name+" "+phoneNumber, Toast.LENGTH_LONG).show();
        }
        phones.close();*/

        ContentResolver cr = getContentResolver();
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);

        if (cur.getCount() > 0) {
            while (cur.moveToNext()) {
                int id=1;
                String id1 = cur.getString(cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone._ID));
                String name = cur.getString(cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));

                if (cur.getInt(cur.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                    Cursor pCur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = ?", new String[]{id1}, null);
                    while (pCur.moveToNext()) {
                        String phoneNo = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        phoneNo=phoneNo.replaceAll("\\s","");
                        /*Toast.makeText(this, "Name: " + name
                                + ", Phone No: " + phoneNo, Toast.LENGTH_SHORT).show();*/
                        StoreContacts.add(name+":"+phoneNo);
                    }
                    pCur.close();
                }
            }
            cur.close();
        }
        //Collections.sort(contactList);
        Set<String> contactSet=new HashSet<>();
        contactSet.addAll(StoreContacts);
        StoreContacts.clear();
        StoreContacts.addAll(contactSet);

        Collections.sort(StoreContacts,new stringComparator());
    }
}

package trainedge.womensafety;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Instructions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructions);

        TextView tvInstruction=(TextView)findViewById(R.id.tv_instruct);
        tvInstruction.setText(
                        "1.) The app has basically been developed for the safety of women but can be used by either of the genders.\n\n" +
                        "2.) On pressing the PANIC button, the app sends an alert message to user's trusted contacts(atmost 5 and atleast 2), with the user's current location.\n\n"+
                        "3.) Please enable the Internet connection and Location Services so that the app can get your current location.\n\n" +
                        "4.) If you don't enable either of the two then also the app will send the message but this time without your current location.\n\n" +
                        "5.)You can change your preferred or trusted contacts anytime.\n\n" +
                                "6.) SMS charges will apply according to your network provider.\n\n"
        );
    }
}

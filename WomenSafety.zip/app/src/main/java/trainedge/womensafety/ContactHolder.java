package trainedge.womensafety;

import android.content.Context;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by hppc on 7/25/2017.
 */

class ContactHolder extends RecyclerView.ViewHolder {

    public final CardView contactCard;
    public  TextView tvName;
    public  TextView tvNumber;
    public ConstraintLayout consLayout;
    public static ArrayList<String> numHolder;
    public ArrayList<String> list=new ArrayList<String>();
    Context context;
    public ContactHolder(View itemView, Context context,ArrayList<String> list) {
        super(itemView);
        this.list=list;
        this.context=context;
        numHolder=new ArrayList<>();
        tvName=(TextView)itemView.findViewById(R.id.tvName);
        tvNumber=(TextView)itemView.findViewById(R.id.tvNumber);
        //tvId=(TextView)itemView.findViewById(R.id.tvId);
        contactCard=(CardView)itemView.findViewById(R.id.contactCard);
        consLayout=(ConstraintLayout)itemView.findViewById(R.id.consLayout);
    }
    }


package com.trainedge.ayush.androiddownloadmanager;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static com.trainedge.ayush.androiddownloadmanager.MainActivity.downloadingItems;
import static com.trainedge.ayush.androiddownloadmanager.R.id.displayList;

public class Downloads extends AppCompatActivity {

    private DownloadedAdapter adapter;
    private ListView displayDownloads;
    private ArrayList<String> rec1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        rec1 = new ArrayList<String>();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_downloads);
        DownloadContract contract = new DownloadContract(this);
        //Intent receivedIntent = getIntent();
        //rec = (ArrayList<String>) receivedIntent.getSerializableExtra("FILES_TO_SEND");
        //rec=MainActivity.downloadingItems;
        Cursor cursor = contract.all();
        cursorTolist(cursor);
        displayDownloads = (ListView)findViewById(R.id.displayDownloads);

        loadDownloadList();

    }
    public void loadDownloadList() {
        adapter = new DownloadedAdapter(this,0 , rec1);
        displayDownloads.setAdapter(adapter);
    }

    private void cursorTolist(Cursor cursor) {
        if(cursor!=null){
            //Toast.makeText(this, "count =" + cursor.getCount(), Toast.LENGTH_SHORT).show();
            if(cursor.getCount()>0){
                while(cursor.moveToNext()){
                    long id = cursor.getLong(0);
                    String name=cursor.getString(1);
                    rec1.add(name);
                }
            }
            else{
                Toast.makeText(this, "No record found", Toast.LENGTH_SHORT).show();
            }
        }cursor.close();
    }


}

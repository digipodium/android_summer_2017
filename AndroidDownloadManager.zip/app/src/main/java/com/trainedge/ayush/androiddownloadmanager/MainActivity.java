package com.trainedge.ayush.androiddownloadmanager;

import android.Manifest;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ActionMode;
import android.view.Gravity;
import android.view.MenuInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    final Context c = this;
    public static long id;
    public static ArrayList<String> downloadingItems = new ArrayList<String>();
    public static ListView displayList;
    public static CustomAdapter adapter;
    private EditText etUrl;
    boolean isPermissionGranted = false;
    public static String name;
    SharedPreferences preferenceManager;
    public static DownloadManager downloadManager;
    final String strPref_Download_ID = "PREF_DOWNLOAD_ID";
    private DownloadContract contract;
    private int counter=0;
    private ArrayList item_to_be_cancelled=new ArrayList<String>();
    private ArrayList item_to_be_cancelledID=new ArrayList<Integer>();
    public static ArrayList<Long> downloadingItemsID=new ArrayList<Long>();
    public static String detail;
    //private android.os.Vibrator vibrator=(Vibrator)this.getSystemService(this.VIBRATOR_SERVICE);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        contract = new DownloadContract(this);
        preferenceManager
                = PreferenceManager.getDefaultSharedPreferences(this);
        downloadManager
                = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        //Button pausedownload = (Button) findViewById(R.id.pause);
        //Button resumedownload = (Button) findViewById(R.id.resume);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);

        displayList = (ListView) findViewById(R.id.displayList);
        adapter = new CustomAdapter(this, 0, downloadingItems);
        displayList.setAdapter(adapter);

        /*displayList.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        displayList.setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {
            @Override
            public void onItemCheckedStateChanged(ActionMode actionMode, int i, long l, boolean b) {
                if(b==true) {
                    counter = counter + 1;
                    item_to_be_cancelledID.add(downloadingItemsID.get(i));
                    item_to_be_cancelled.add(downloadingItems.get(i));
                }else if(b==false){
                    counter=counter-1;
                    item_to_be_cancelledID.remove((downloadingItemsID.get(i)));
                    item_to_be_cancelled.remove((downloadingItems.get(i)));
                }
                if(counter==1){
                    actionMode.setTitle("1 Item selected");
                    //getActionBar().hide();
                }
                else if (counter==0){
                    //getActionBar().show();
                    actionMode.setTitle("");
                }
                else {
                    //getActionBar().hide();
                    actionMode.setTitle(counter + "  Items selected");
                }
            }

            @Override
            public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
                MenuInflater inflater=actionMode.getMenuInflater();
                inflater.inflate(R.menu.list_select_menu,menu);
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
                switch(menuItem.getItemId()){
                    case R.id.cancel:
                        for(int i=0;i<item_to_be_cancelled.size();i++){
                            long delid=(long )item_to_be_cancelledID.get(i);
                            String delname=(String)item_to_be_cancelled.get(i);
                            downloadManager.remove(delid);
                            if(downloadingItemsID.contains(delid)){
                                downloadingItemsID.remove(delid);
                            }
                            if(downloadingItems.contains(delname)){
                                downloadingItems.remove(delname);
                            }
                            item_to_be_cancelled.remove(delname);
                            item_to_be_cancelledID.remove(delid);
                        }
                        adapter.notifyDataSetChanged();
                        Toast.makeText(c, "Selected Downloads Cancelled", Toast.LENGTH_SHORT).show();
                        counter=0;
                        actionMode.finish();
                        return true;
                    default:
                        return false;
                }
            }

            @Override
            public void onDestroyActionMode(ActionMode actionMode) {

            }
        });*/

        isExternalStoragePresent();
        if (!isPermissionGranted) {
            handlePermission();
        }


        //FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        /*fab.setOnClickListener(new View.OnClickListener() {



            @Override
            public void onClick(final View v) {
                LayoutInflater layoutInflaterAndroid = LayoutInflater.from(c);
                View mView = layoutInflaterAndroid.inflate(R.layout.user_input_dialog_box, null);
                final AlertDialog.Builder alertDialogBuilderUserInput = new AlertDialog.Builder(c);
                alertDialogBuilderUserInput.setView(mView);


                alertDialogBuilderUserInput
                        .setCancelable(false)
                        .setPositiveButton("START", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogBox, int id) {
                                etUrl = (EditText)dialogBox.findViewById(R.id.etUrl);
                                m_Text = etUrl.getText().toString();
                                Uri image_uri = Uri.parse(m_Text);
                                DownloadData(image_uri, v);

                            }
                        })

                        .setNegativeButton("CANCEL",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialogBox, int id) {
                                        dialogBox.cancel();
                                    }
                                });
                AlertDialog alertDialogAndroid = alertDialogBuilderUserInput.create();
                alertDialogAndroid.show();
            }

        });*/

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog = new Dialog(c);
                dialog.setContentView(R.layout.user_input_dialog_box);
                dialog.setTitle("New Download");

                DisplayMetrics metrics = MainActivity.this.getResources().getDisplayMetrics();
                int width = metrics.widthPixels;

                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(dialog.getWindow().getAttributes());
                layoutParams.width = width;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                layoutParams.gravity = Gravity.CENTER;
                dialog.getWindow().setAttributes(layoutParams);

                final View layout = View.inflate(MainActivity.this, R.layout.user_input_dialog_box, null);
                Button button = (Button) dialog.findViewById(R.id.button);
                etUrl = (EditText) dialog.findViewById(R.id.etUrl);


                button.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        //Intent  intent = new Intent(MainActivity.this,MyReceiver.class);

                        String url = etUrl.getText().toString();
                        Uri image_uri = Uri.parse(url);
                        String urlsubstring = url.substring(url.lastIndexOf('/') + 1, url.length());
                        name = urlsubstring.replaceAll("%20", " ").replaceAll("%28","(").replaceAll("%29",")");
                        if(url.isEmpty()){
                            etUrl.setError("URL cannot be empty");
                            return;
                        }
                        //long rowno = contract.add(name);
                        /*if(rowno!=-1)
                        {
                            Toast.makeText(MainActivity.this, "Successfully added in db", Toast.LENGTH_SHORT).show();
                        }
                        else
                            Toast.makeText(MainActivity.this, "some error in adding in db", Toast.LENGTH_SHORT).show();
                         */
                        //name = fileName.substring(0, fileName.lastIndexOf('.'));
                        id = DownloadData(image_uri, v);
                        //String id1=""+id;
                        // String info=id1+":"+name;
                        //Toast.makeText(MainActivity.this, name, Toast.LENGTH_SHORT).show();
                        detail=id+":"+name;
                        downloadingItems.add(id+":"+name);
                        downloadingItemsID.add(id);
                        /*Intent intent = new Intent(MainActivity.this, Downloads.class);
                        intent.putExtra("FILES_TO_SEND", downloadingItems);*/

                        loadList();
                        //MyReceiver Receiver = new MyReceiver();
                        //Receiver.onReceive(MainActivity.this,intent);
                        //intent.putExtra("downloadId",id);
                        //sendBroadcast(intent);
                        dialog.dismiss();
                    }
                });
                dialog.show();

            }
        });
    }


    public void loadList() {
        adapter = new CustomAdapter(this, 0, downloadingItems);
        displayList.setAdapter(adapter);
    }



    private long DownloadData(Uri uri, View v) {

        long downloadReference;

        // Create request for android download manager
        downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        DownloadManager.Request request = new DownloadManager.Request(uri);

        //Setting title of request
        request.setTitle(name);

        //Setting description of request
        request.setDescription("Downloading...");

        //Set the local destination for the downloaded file to a path
        //within the application's external files directory

        request.setDestinationInExternalPublicDir("DownloadManager", name);


        //Enqueue download and save into referenceId
        downloadReference = downloadManager.enqueue(request);
        SharedPreferences.Editor PrefEdit = preferenceManager.edit();
        PrefEdit.putLong(strPref_Download_ID, id);
        PrefEdit.commit();


        return downloadReference;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.ShowDownloads) {

            Intent i = new Intent(this, Downloads.class);
            startActivity(i);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);


     /*private BroadcastReceiver downloadReceiver = new BroadcastReceiver() {

         @Override
         public void onReceive(Context context, Intent intent) {

             //check if the broadcast message is for our enqueued download
             long referenceId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);

             if(referenceId == id) {

                 Toast toast = Toast.makeText(MainActivity.this,
                         "Image Download Complete", Toast.LENGTH_LONG);
                 toast.setGravity(Gravity.TOP, 25, 400);
                 toast.show();
             }

         }
     };


    /* @Override
     public Intent registerReceiver(BroadcastReceiver receiver, IntentFilter filter) {
         return registerReceiver(downloadReceiver, filter);

     }*/
    private boolean isExternalStoragePresent() {

        boolean mExternalStorageAvailable = false;
        boolean mExternalStorageWriteable = false;
        String state = Environment.getExternalStorageState();

        if (Environment.MEDIA_MOUNTED.equals(state)) {
            // We can read and write the media
            mExternalStorageAvailable = mExternalStorageWriteable = true;
            //Toast.makeText(c, "we can read and write Media", Toast.LENGTH_SHORT).show();
        } else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            // We can only read the media
            mExternalStorageAvailable = true;
            mExternalStorageWriteable = false;
            //Toast.makeText(c, "we can only read", Toast.LENGTH_SHORT).show();
        } else {
            // Something else is wrong. It may be one of many other states, but
            // all we need
            // to know is we can neither read nor write
            mExternalStorageAvailable = mExternalStorageWriteable = false;
            //Toast.makeText(c, "We can neither read nor write", Toast.LENGTH_SHORT).show();
        }
        if (!((mExternalStorageAvailable) && (mExternalStorageWriteable))) {
            Toast.makeText(this, "SD card not present", Toast.LENGTH_LONG)
                    .show();

        }
        return (mExternalStorageAvailable) && (mExternalStorageWriteable);
    }

    private void handlePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 212);
                return;
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (requestCode == 212) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                isPermissionGranted = true;
            } else {
                handlePermission();
            }
        }
    }

   /* @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        super.onResume();

        CheckDwnloadStatus();

        IntentFilter intentFilter
                = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        registerReceiver(downloadReceiver, intentFilter);

    }


    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        unregisterReceiver(downloadReceiver);
    }*/
   /*private BroadcastReceiver downloadReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();

            if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)) {
                //Show a notification
                Toast.makeText(context, "Downloaded to Internal Storage -> Download Manager", Toast.LENGTH_SHORT).show();

            // TODO Auto-generated method stub
            CheckDownloadStatus();
        }
    }
   };*/




    private void CheckDownloadStatus(){

        // TODO Auto-generated method stub
        DownloadManager.Query query = new DownloadManager.Query();
        long id = preferenceManager.getLong(strPref_Download_ID, 0);
        query.setFilterById(id);
        Cursor cursor = downloadManager.query(query);
        if(cursor.moveToFirst()){
            int columnIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
            int status = cursor.getInt(columnIndex);
            int columnReason = cursor.getColumnIndex(DownloadManager.COLUMN_REASON);
            int reason = cursor.getInt(columnReason);

            switch(status){
                case DownloadManager.STATUS_FAILED:
                    String failedReason = "";
                    switch(reason){
                        case DownloadManager.ERROR_CANNOT_RESUME:
                            failedReason = "ERROR_CANNOT_RESUME";
                            break;
                        case DownloadManager.ERROR_DEVICE_NOT_FOUND:
                            failedReason = "ERROR_DEVICE_NOT_FOUND";
                            break;
                        case DownloadManager.ERROR_FILE_ALREADY_EXISTS:
                            failedReason = "ERROR_FILE_ALREADY_EXISTS";
                            break;
                        case DownloadManager.ERROR_FILE_ERROR:
                            failedReason = "ERROR_FILE_ERROR";
                            break;
                        case DownloadManager.ERROR_HTTP_DATA_ERROR:
                            failedReason = "ERROR_HTTP_DATA_ERROR";
                            break;
                        case DownloadManager.ERROR_INSUFFICIENT_SPACE:
                            failedReason = "ERROR_INSUFFICIENT_SPACE";
                            break;
                        case DownloadManager.ERROR_TOO_MANY_REDIRECTS:
                            failedReason = "ERROR_TOO_MANY_REDIRECTS";
                            break;
                        case DownloadManager.ERROR_UNHANDLED_HTTP_CODE:
                            failedReason = "ERROR_UNHANDLED_HTTP_CODE";
                            break;
                        case DownloadManager.ERROR_UNKNOWN:
                            failedReason = "ERROR_UNKNOWN";
                            break;
                    }

                    Toast.makeText(MainActivity.this,
                            "FAILED: " + failedReason,
                            Toast.LENGTH_LONG).show();
                    break;
                case DownloadManager.STATUS_PAUSED:
                    String pausedReason = "";

                    switch(reason){
                        case DownloadManager.PAUSED_QUEUED_FOR_WIFI:
                            pausedReason = "PAUSED_QUEUED_FOR_WIFI";
                            break;
                        case DownloadManager.PAUSED_UNKNOWN:
                            pausedReason = "PAUSED_UNKNOWN";
                            break;
                        case DownloadManager.PAUSED_WAITING_FOR_NETWORK:
                            pausedReason = "PAUSED_WAITING_FOR_NETWORK";
                            break;
                        case DownloadManager.PAUSED_WAITING_TO_RETRY:
                            pausedReason = "PAUSED_WAITING_TO_RETRY";
                            break;
                    }

                    Toast.makeText(MainActivity.this,
                            "PAUSED: " + pausedReason,
                            Toast.LENGTH_LONG).show();
                    break;
                case DownloadManager.STATUS_PENDING:
                    Toast.makeText(MainActivity.this,
                            "PENDING",
                            Toast.LENGTH_LONG).show();
                    break;
                case DownloadManager.STATUS_RUNNING:
                    Toast.makeText(MainActivity.this,
                            "RUNNING",
                            Toast.LENGTH_LONG).show();
                    break;
                case DownloadManager.STATUS_SUCCESSFUL:

                    Toast.makeText(MainActivity.this,
                            "SUCCESSFUL",
                            Toast.LENGTH_LONG).show();
                    GetFile();
                    downloadManager.remove(id);
                    break;
            }
        }
    }
    private void GetFile(){
        //Retrieve the saved request id
        long downloadID = preferenceManager.getLong(strPref_Download_ID, 0);

        ParcelFileDescriptor file;
        try {
            file = downloadManager.openDownloadedFile(downloadID);
            FileInputStream fileInputStream
                    = new ParcelFileDescriptor.AutoCloseInputStream(file);
            Bitmap bm = BitmapFactory.decodeStream(fileInputStream);

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


}

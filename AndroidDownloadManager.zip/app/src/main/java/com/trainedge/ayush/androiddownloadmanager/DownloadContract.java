package com.trainedge.ayush.androiddownloadmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



public class DownloadContract {
    private static Helper helper=null;

    /*Helper class */
    class Helper extends SQLiteOpenHelper{

        public Helper(Context context){
            super(context,"downloadDb",null,1);
        }
        @Override
        public void onCreate(SQLiteDatabase db) {
            String query="CREATE TABLE download ( _id INTEGER PRIMARY KEY AUTOINCREMENT, name VARCHAR(255));";
            db.execSQL(query);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            String query="DROP TABLE IF EXISTS download";
            db.execSQL(query);
            onCreate(db);
        }
    }

    //constants interface
    interface Constants{
        public static final String TBL_DOWNLOAD ="download";
        public static final String COL_NAME ="name";
        public static final String COL_ID ="_id";

    }

    //constructor

    public DownloadContract(Context context) {
        helper=new Helper(context);
    }

    //Crud methods
    public static long add(String name){
        SQLiteDatabase db=helper.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(Constants.COL_NAME,name);
        return db.insert(Constants.TBL_DOWNLOAD,null,values);
    }
    public Cursor all(){
        SQLiteDatabase db=helper.getReadableDatabase();
        return db.query(Constants.TBL_DOWNLOAD,null,null,null,null,null,null);
    }
    public int deleteById(String id){
        SQLiteDatabase db=helper.getWritableDatabase();
        String where=Constants.COL_ID+"=?";
        String[] whereArgs=new String[]{id};
        return db.delete(Constants.TBL_DOWNLOAD,where,whereArgs);
    }
    public int updateById(String id,String name){
        SQLiteDatabase db=helper.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(Constants.COL_NAME,name);
        String where=Constants.COL_ID+"=?";
        String[] whereArgs=new String[]{id};
        return db.update(Constants.TBL_DOWNLOAD,values,where,whereArgs);
    }

}

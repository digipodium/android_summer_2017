package com.trainedge.ayush.androiddownloadmanager;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Ayush Srivastava on 29-07-2017.
 */

public class DownloadedAdapter extends ArrayAdapter<String> {

    Context context;
    int resource;
    ArrayList<String> list;
    private TextView tvName;

    public DownloadedAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull ArrayList<String> list) {
        super(context, resource, list);
        this.context=context;
        this.resource=resource;
        this.list=list;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater= LayoutInflater.from(context);
        View downloadingView=inflater.inflate(R.layout.display_downloaded_items,null);
        String info=list.get(position);
        //String str[]=info.split(":");
        //String id=str[0];
        //String name=str[1];
        tvName=(TextView)downloadingView.findViewById(R.id.tvdownloaded);

        tvName.setText(info);
        return downloadingView;
    }
}

package com.trainedge.ayush.androiddownloadmanager;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.view.Gravity;
import android.widget.Toast;

import static android.R.attr.id;

public class MyReceiver extends BroadcastReceiver {

    IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (action.equals(DownloadManager.ACTION_DOWNLOAD_COMPLETE))
            {
                DownloadManager.Query query = new DownloadManager.Query();
                query.setFilterById(intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, 0));
                DownloadManager manager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
                Cursor cursor = manager.query(query);
                if (cursor.moveToFirst()) {
                    if (cursor.getCount() > 0) {

                        int status = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS));
                        Long download_id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID,0);

                        // status contain Download Status
                        // download_id contain current download reference id

                        if (status == DownloadManager.STATUS_SUCCESSFUL)
                        {
                            //String file = cursor.getString(cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_FILENAME));

                            //file contains downloaded file name

                            // do your stuff here on download success
                            Toast.makeText(context, "Internal Storage -> Download Manager", Toast.LENGTH_SHORT).show();
                            DownloadContract.add(MainActivity.name);
                            //final String info=MainActivity.downloadingItems.get(position);
                            String str[]=MainActivity.detail.split(":");
                            final long id=Long.parseLong(str[0]);
                            String name=str[1];
                            MainActivity.downloadingItems.remove(MainActivity.detail);
                            //MainActivity.downloadingItemsID.remove(MainActivity.id);
                            MainActivity.adapter.notifyDataSetChanged();
                        }
                    }
                }
                cursor.close();
            }

            //check if the broadcast message is for our enqueued download
            /*long referenceId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            //long downloadId = intent.getLongExtra("downloadId",0);
            if(referenceId == MainActivity.id) {

                Toast toast = Toast.makeText(context,
                        "Download Complete", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.TOP, 25, 400);
                toast.show();
            }
            else Toast.makeText(context, "Downloaded", Toast.LENGTH_SHORT).show();
            MainActivity.downloadingItems.remove(id);*/
        }
    };

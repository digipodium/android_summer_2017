package com.trainedge.ayush.androiddownloadmanager;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Ayush Srivastava on 29-07-2017.
 */

public class CustomAdapter extends ArrayAdapter<String> {

    Context context;
    int resource;
    ArrayList<String> list;
    private TextView tvName;
    private FloatingActionButton btnCancel;

    public CustomAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull ArrayList<String> list) {
        super(context, resource, list);
        this.context=context;
        this.resource=resource;
        this.list=list;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater= LayoutInflater.from(context);
        View downloadingView=inflater.inflate(R.layout.display_items,null);
        final String info=list.get(position);
        String str[]=info.split(":");
        final long id=Long.parseLong(str[0]);
        String name=str[1];
        tvName=(TextView)downloadingView.findViewById(R.id.tvName);
        btnCancel=(FloatingActionButton) downloadingView.findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.downloadManager.remove(id);
                MainActivity.downloadingItems.remove(info);
                notifyDataSetChanged();
            }
        });
        tvName.setText(name);
        return downloadingView;
    }
}

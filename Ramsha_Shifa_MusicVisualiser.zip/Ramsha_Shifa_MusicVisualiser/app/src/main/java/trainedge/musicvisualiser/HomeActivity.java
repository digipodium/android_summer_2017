package trainedge.musicvisualiser;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.audiofx.Visualizer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageButton btnPlay;
    private ImageButton btnNext;
    private ImageButton btnPrevious;
    private ImageButton btnPlaylist;


    private SeekBar seek;
    private TextView songTitleLabel;

    // Media Player
    private MediaPlayer mp;


    private ImageButton btnForward;
    private ImageButton btnBackward;
    private Thread updateSeekBar;
    private ArrayList mySongs;
    private int position;
    private Uri u;
    private ImageButton btnShuffle;
    boolean isPermissionGranted = false;
    private VisualizerView mVisualizerView;
    private Visualizer mVisualizer;
    private String title;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        btnPlay = (ImageButton) findViewById(R.id.btnPlay);
        btnNext = (ImageButton) findViewById(R.id.btnNext);
        btnPrevious = (ImageButton) findViewById(R.id.btnPrevious);

        btnForward = (ImageButton) findViewById(R.id.btnForward);
        btnBackward = (ImageButton) findViewById(R.id.btnBackward);


        seek = (SeekBar) findViewById(R.id.seek);
        songTitleLabel = (TextView) findViewById(R.id.songTitleLabel);


        btnPlay.setOnClickListener(this);
        btnNext.setOnClickListener(this);

        btnPrevious.setOnClickListener(this);

        btnBackward.setOnClickListener(this);
        btnForward.setOnClickListener(this);
        mVisualizerView = (VisualizerView) findViewById(R.id.myvisualizerview);
        handlePermission();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 212) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                isPermissionGranted = true;
            } else {
                handlePermission();
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isFinishing() && mp != null) {
            if (mVisualizer != null) mVisualizer.release();
            mp.release();
            mp = null;
        }
    }

    private void initAudio() {
        setVolumeControlStream(AudioManager.STREAM_MUSIC);



        setupVisualizerFxAndUI();
        mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                if (mVisualizer != null) mVisualizer.setEnabled(false);
            }


        });
        mp.start();
        if (mVisualizer != null) mVisualizer.setEnabled(true);

    }

    private void handlePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.MODIFY_AUDIO_SETTINGS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.MODIFY_AUDIO_SETTINGS}, 212);


            } else {
                isPermissionGranted = true;
                initAudio();

            }
        } else {
            isPermissionGranted = true;
            initAudio();

        }
    }


    private void setupVisualizerFxAndUI() {

        if (mp != null) {
            mp.stop();
            mp.release();


        }

        Intent i = getIntent();
        Bundle b = i.getExtras();
        mySongs = (ArrayList) b.getParcelableArrayList("songlist");
        position = b.getInt("pos", 0);
        title = b.getString("songTitleLabel");
        songTitleLabel.setText(title);
        u = Uri.parse(mySongs.get(position).toString());

        mp = MediaPlayer.create(getApplicationContext(), u);
        mp.start();
        seek.setMax(mp.getDuration());

        //super.run();
        updateSeekBar = new Thread() {
            @Override
            public void run() {
                int totalDuration = mp.getDuration();
                int currentPosition = 0;


                while (currentPosition < totalDuration) {
                    try {
                        sleep(500);
                        currentPosition = mp.getCurrentPosition();
                        seek.setProgress(currentPosition);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }catch (NullPointerException e){

                    }
                }
            }        //super.run();

        };

        kickStart();





    }

    private void kickStart() {
        updateSeekBar.start();
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {


            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mp.seekTo(seekBar.getProgress());
            }
        });

        try {
            mVisualizer = new Visualizer(mp.getAudioSessionId());
            mVisualizer.setCaptureSize(Visualizer.getCaptureSizeRange()[1]);
            mVisualizer.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                public void onWaveFormDataCapture(Visualizer visualizer, byte[] bytes, int samplingRate) {
                    try {
                        mVisualizerView.updateVisualizer(bytes);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFftDataCapture(Visualizer visualizer, byte[] bytes, int samplingRate) {

                }
            }, Visualizer.getMaxCaptureRate() / 2, true, false);
        } catch (Exception e) {

        }
    }


    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.btnPlay:
                if (mp.isPlaying()) {
                    btnPlay.setImageResource(R.drawable.btn_play);
                    mp.pause();
                } else {

                    btnPlay.setImageResource(R.drawable.btn_pause);
                    mp.start();
                }

                break;
            case R.id.btnForward:
                mp.seekTo(mp.getCurrentPosition() + 5000);
                break;
            case R.id.btnBackward:
                mp.seekTo(mp.getCurrentPosition() - 5000);

                break;
            case R.id.btnNext:
                mp.stop();
                mp.release();
                position = (position + 1) % mySongs.size();
                u = Uri.parse(mySongs.get(position).toString());
                mp = MediaPlayer.create(getApplicationContext(), u);
                mp.start();
                seek.setMax(mp.getDuration());
                break;
            case R.id.btnPrevious:
                mp.stop();
                mp.release();
                position = (position - 1 < 0) ? mySongs.size() - 1 : position - 1;


                u = Uri.parse(mySongs.get(position).toString());
                mp = MediaPlayer.create(getApplicationContext(), u);
                mp.start();
                seek.setMax(mp.getDuration());
                break;

        }
    }
}




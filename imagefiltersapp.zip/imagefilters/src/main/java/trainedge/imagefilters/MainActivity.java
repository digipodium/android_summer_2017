package trainedge.imagefilters;

import android.content.Intent;
//import android.database.Cursor;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
//import android.graphics.drawable.BitmapDrawable;
//import android.graphics.drawable.Drawable;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Environment;
//import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int SELECTED_PICTURE=1;
    private ImageButton btnPick;
    private ImageView iv;
    private ImageButton invert;
    private Bitmap b;
    private Bitmap filtered;
    private ImageButton watermark;
    private ImageButton btnSave;
    private String currentImage;
    private Bitmap bitmap;
    private ImageButton grayScale;
    private static final double value=100;
    private static final float round=100;
    private static final int degree=100;
    private ImageButton contrast;
    private ImageButton colorGreen;
    private ImageButton colorBlue;
    private ImageButton smooth;
    private ImageButton roundCorner;
    private ImageButton flea;
    public static final int COLOR_MIN = 0x00;
    public static final int depth = 5;
    public static final int COLOR_MAX = 0xFF;
    public static final int shadingColorYellow= Color.YELLOW;
    public static final int shadingColorGreen = Color.GREEN;
    public static final int shadingColorCyan = Color.CYAN;
    public static final int shadingColorRed = Color.RED;
    private ImageButton black;
    private ImageButton tint;
    public static final double PI = 3.14159d;
    public static final double FULL_CIRCLE_DEGREE = 360d;
    public static final double HALF_CIRCLE_DEGREE = 180d;
    public static final double RANGE = 256d;
    private ImageButton sepiaGreen;
    private ImageButton shadingYellow;
    private ImageButton shadingGreen;
    private ImageButton shadingCyan;
    private ImageButton shadingRed;
    private ImageButton btnShare;
    private EditText etComment;
    private String watermarkString;
    private Point location;
    public static final int alpha=50;
    public static final int size=50;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnPick = (ImageButton)findViewById(R.id.btnPick);
        iv = (ImageView)findViewById(R.id.iv);
        btnPick.setOnClickListener(this);
        invert = (ImageButton)findViewById(R.id.invert);
        watermark = (ImageButton)findViewById(R.id.watermark);
        btnSave = (ImageButton)findViewById(R.id.btnSave);
        grayScale = (ImageButton)findViewById(R.id.grayScale);
        contrast = (ImageButton)findViewById(R.id.contrast);
        colorGreen = (ImageButton)findViewById(R.id.colorGreen);
        colorBlue = (ImageButton)findViewById(R.id.colorBlue);
        smooth = (ImageButton)findViewById(R.id.smooth);
        roundCorner = (ImageButton)findViewById(R.id.roundCorner);
        flea = (ImageButton)findViewById(R.id.flea);
        black = (ImageButton)findViewById(R.id.black);
        tint = (ImageButton)findViewById(R.id.tint);
        sepiaGreen = (ImageButton)findViewById(R.id.sepiaGreen);
        shadingYellow = (ImageButton)findViewById(R.id.shadingYellow);
        shadingGreen = (ImageButton)findViewById(R.id.shadingGreen);
        shadingCyan = (ImageButton)findViewById(R.id.shadingCyan);
        shadingRed = (ImageButton)findViewById(R.id.shadingRed);
        btnShare = (ImageButton)findViewById(R.id.btnShare);




        invert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(b==null){
                    Toast.makeText(MainActivity.this, "Select a picture!", Toast.LENGTH_SHORT).show();
                }
                filtered = doInvert(b);
                iv.setImageBitmap(filtered);
            }
        });


        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View content=findViewById(R.id.lay);
                bitmap = getScreenShot(content);
                currentImage = "image" + System.currentTimeMillis() + ".png";
                store(filtered, currentImage);
            }
        });
        grayScale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filtered=doGreyscale(b);
                iv.setImageBitmap(filtered);
            }
        });
        contrast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filtered=createContrast(b,value);
                iv.setImageBitmap(filtered);
            }
        });
        colorGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filtered=doColorGreen(b);
                iv.setImageBitmap(filtered);
            }
        });
        colorBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filtered=doColorBlue(b);
                iv.setImageBitmap(filtered);
            }
        });
       roundCorner.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               filtered=roundedCorner(b,round);
               iv.setImageBitmap(filtered);
           }
       });
        flea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filtered=applyFleaEffect(b);
                iv.setImageBitmap(filtered);
            }
        });
        black.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filtered=applyBlackFilter(b);
                iv.setImageBitmap(filtered);
            }
        });
        tint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filtered=tintImage(b,degree);
                iv.setImageBitmap(filtered);
            }
        });
        sepiaGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filtered=createSepiaGreen(b,depth);
                iv.setImageBitmap(filtered);
            }
        });
        shadingYellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                filtered=applyShadingYellow(b,shadingColorYellow);
                iv.setImageBitmap(filtered);
            }
        });
        shadingGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                filtered=applyShadingGreen(b,shadingColorGreen);
                iv.setImageBitmap(filtered);
            }
        });
        shadingCyan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                filtered=applyShadingCyan(b,shadingColorCyan);
                iv.setImageBitmap(filtered);
            }
        });
        shadingRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                filtered=applyShadingRed(b,shadingColorRed);
                iv.setImageBitmap(filtered);
            }
        });
        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shareImage(currentImage);
            }
        });
        watermark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etComment = (EditText)findViewById(R.id.etComment);
                watermarkString = etComment.getText().toString();
                if (watermarkString.isEmpty()){
                    Toast.makeText(MainActivity.this, "Write a comment!", Toast.LENGTH_SHORT).show();
                }
                else {

                    location = new Point(150,300);
                    filtered = mark(b, watermarkString, location, Color.BLACK, alpha, size);
                    iv.setImageBitmap(filtered);
                }
            }
        });
        smooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filtered=doSmooth(b,value);
                iv.setImageBitmap(filtered);
            }
        });
    }

    private Bitmap doSmooth(Bitmap b, double value) {

            ConvolutionMatrix convMatrix = new ConvolutionMatrix(3);
            convMatrix.setAll(1);
            convMatrix.Matrix[1][1] = value;
            convMatrix.Factor = value + 8;
            convMatrix.Offset = 1;
            return ConvolutionMatrix.computeConvolution3x3(b, convMatrix);

    }
   

    private Bitmap mark(Bitmap b, String watermarkString, Point location, int black, int alpha, int size) {
        int w = b.getWidth();
        int h = b.getHeight();
        Bitmap result = Bitmap.createBitmap(w, h, b.getConfig());

        Canvas canvas = new Canvas(result);
        canvas.drawBitmap(b, 0, 0, null);

        Paint paint = new Paint();
        paint.setColor(black);
        paint.setAlpha(alpha);
        paint.setTextSize(size);
        paint.setAntiAlias(true);

        canvas.drawText(watermarkString, location.x, location.y, paint);

        return result;
    }

    private void shareImage(String currentImage) {
        String directPath=Environment.getExternalStorageDirectory().getAbsolutePath()+"/FILTEREDIMAGES";
        Uri uri=Uri.fromFile(new File(directPath,currentImage));
        Intent intent=new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("image/*");

        intent.putExtra(Intent.EXTRA_SUBJECT,"");
        intent.putExtra(Intent.EXTRA_TEXT,"");
        intent.putExtra(Intent.EXTRA_STREAM,uri);

        try {
            startActivity(Intent.createChooser(intent,"Share via"));
        }
        catch (Exception e){
            Toast.makeText(this, "No sharing app found!", Toast.LENGTH_SHORT).show();
        }

    }

    private Bitmap applyShadingRed(Bitmap b, int shadingColorRed) {
        // get image size
        int width = b.getWidth();
        int height = b.getHeight();
        int[] pixels = new int[width * height];
        // get pixel array from source
        b.getPixels(pixels, 0, width, 0, 0, width, height);

        int index = 0;
        // iteration through pixels
        for(int y = 0; y < height; ++y) {
            for(int x = 0; x < width; ++x) {
                // get current index in 2D-matrix
                index = y * width + x;
                // AND
                pixels[index] &= shadingColorRed;
            }
        }
        // output bitmap
        Bitmap bmOut = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bmOut.setPixels(pixels, 0, width, 0, 0, width, height);
        return bmOut;
    }

    private Bitmap applyShadingCyan(Bitmap b, int shadingColorCyan) {
        // get image size
        int width = b.getWidth();
        int height = b.getHeight();
        int[] pixels = new int[width * height];
        // get pixel array from source
        b.getPixels(pixels, 0, width, 0, 0, width, height);

        int index = 0;
        // iteration through pixels
        for(int y = 0; y < height; ++y) {
            for(int x = 0; x < width; ++x) {
                // get current index in 2D-matrix
                index = y * width + x;
                // AND
                pixels[index] &= shadingColorCyan;
            }
        }
        // output bitmap
        Bitmap bmOut = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bmOut.setPixels(pixels, 0, width, 0, 0, width, height);
        return bmOut;
    }

    private Bitmap applyShadingGreen(Bitmap b, int shadingColorGreen) {
        // get image size
        int width = b.getWidth();
        int height = b.getHeight();
        int[] pixels = new int[width * height];
        // get pixel array from source
        b.getPixels(pixels, 0, width, 0, 0, width, height);

        int index = 0;
        // iteration through pixels
        for(int y = 0; y < height; ++y) {
            for(int x = 0; x < width; ++x) {
                // get current index in 2D-matrix
                index = y * width + x;
                // AND
                pixels[index] &= shadingColorGreen;
            }
        }
        // output bitmap
        Bitmap bmOut = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bmOut.setPixels(pixels, 0, width, 0, 0, width, height);
        return bmOut;
    }

    private Bitmap applyShadingYellow(Bitmap b, int shadingColorYellow) {
        // get image size
        int width = b.getWidth();
        int height = b.getHeight();
        int[] pixels = new int[width * height];
        // get pixel array from source
        b.getPixels(pixels, 0, width, 0, 0, width, height);

        int index = 0;
        // iteration through pixels
        for(int y = 0; y < height; ++y) {
            for(int x = 0; x < width; ++x) {
                // get current index in 2D-matrix
                index = y * width + x;
                // AND
                pixels[index] &= shadingColorYellow;
            }
        }
        // output bitmap
        Bitmap bmOut = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bmOut.setPixels(pixels, 0, width, 0, 0, width, height);
        return bmOut;
    }

    private Bitmap createSepiaGreen(Bitmap b, int depth) {
        // image size
        int width = b.getWidth();
        int height = b.getHeight();
        // create output bitmap
        Bitmap bmOut = Bitmap.createBitmap(width, height, b.getConfig());
        // constant grayscale
        final double GS_RED = 0.3;
        final double GS_GREEN = 0.59;
        final double GS_BLUE = 0.11;
        // color information
        int A, R, G, B;
        int pixel;

        // scan through all pixels
        for(int x = 0; x < width; ++x) {
            for(int y = 0; y < height; ++y) {
                // get pixel color
                pixel = b.getPixel(x, y);
                // get color on each channel
                A = Color.alpha(pixel);
                R = Color.red(pixel);
                G = Color.green(pixel);
                B = Color.blue(pixel);
                // apply grayscale sample
                B = G = R = (int)(GS_RED * R + GS_GREEN * G + GS_BLUE * B);

                // apply intensity level for sepid-toning on each channel
                R += (depth * 5);
                if(R > 255) { R = 255; }

                G += (depth * 10);
                if(G > 255) { G = 255; }

                B += (depth * 5);
                if(B > 255) { B = 255; }

                // set new pixel color to output image
                bmOut.setPixel(x, y, Color.argb(A, R, G, B));
            }
        }

        // return final image
        return bmOut;
    }

    private Bitmap tintImage(Bitmap b, int degree) {
        int width = b.getWidth();
        int height = b.getHeight();

        int[] pix = new int[width * height];
        b.getPixels(pix, 0, width, 0, 0, width, height);

        int RY, GY, BY, RYY, GYY, BYY, R, G, B, Y;
        double angle = (PI * (double)degree) / HALF_CIRCLE_DEGREE;

        int S = (int)(RANGE * Math.sin(angle));
        int C = (int)(RANGE * Math.cos(angle));

        for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++) {
                int index = y * width + x;
                int r = ( pix[index] >> 16 ) & 0xff;
                int g = ( pix[index] >> 8 ) & 0xff;
                int c = pix[index] & 0xff;
                RY = ( 70 * r - 59 * g - 11 * c ) / 100;
                GY = (-30 * r + 41 * g - 11 * c ) / 100;
                BY = (-30 * r - 59 * g + 89 * c ) / 100;
                Y  = ( 30 * r + 59 * g + 11 * c ) / 100;
                RYY = ( S * BY + C * RY ) / 256;
                BYY = ( C * BY - S * RY ) / 256;
                GYY = (-51 * RYY - 19 * BYY ) / 100;
                R = Y + RYY;
                R = ( R < 0 ) ? 0 : (( R > 255 ) ? 255 : R );
                G = Y + GYY;
                G = ( G < 0 ) ? 0 : (( G > 255 ) ? 255 : G );
                B = Y + BYY;
                B = ( B < 0 ) ? 0 : (( B > 255 ) ? 255 : B );
                pix[index] = 0xff000000 | (R << 16) | (G << 8 ) | B;
            }

        Bitmap outBitmap = Bitmap.createBitmap(width, height, b.getConfig());
        outBitmap.setPixels(pix, 0, width, 0, 0, width, height);

        pix = null;

        return outBitmap;
    }

    private Bitmap applyBlackFilter(Bitmap b) {
        // get image size
        int width = b.getWidth();
        int height = b.getHeight();
        int[] pixels = new int[width * height];
        // get pixel array from source
        b.getPixels(pixels, 0, width, 0, 0, width, height);
        // random object
        Random random = new Random();

        int R, G, B, index = 0, thresHold = 0;
        // iteration through pixels
        for(int y = 0; y < height; ++y) {
            for(int x = 0; x < width; ++x) {
                // get current index in 2D-matrix
                index = y * width + x;
                // get color
                R = Color.red(pixels[index]);
                G = Color.green(pixels[index]);
                B = Color.blue(pixels[index]);
                // generate threshold
                thresHold = random.nextInt(COLOR_MAX);
                if(R < thresHold && G < thresHold && B < thresHold) {
                    pixels[index] = Color.rgb(COLOR_MIN, COLOR_MIN, COLOR_MIN);
                }
            }
        }
        // output bitmap
        Bitmap bmOut = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bmOut.setPixels(pixels, 0, width, 0, 0, width, height);
        return bmOut;
    }

    private Bitmap applyFleaEffect(Bitmap b) {
        // get image size
        int width = b.getWidth();
        int height = b.getHeight();
        int[] pixels = new int[width * height];
        // get pixel array from source
        b.getPixels(pixels, 0, width, 0, 0, width, height);
        // a random object
        Random random = new Random();

        int index = 0;
        // iteration through pixels
        for(int y = 0; y < height; ++y) {
            for(int x = 0; x < width; ++x) {
                // get current index in 2D-matrix
                index = y * width + x;
                // get random color
                int randColor = Color.rgb(random.nextInt(COLOR_MAX),
                        random.nextInt(COLOR_MAX), random.nextInt(COLOR_MAX));
                // OR
                pixels[index] |= randColor;
            }
        }
        // output bitmap
        Bitmap bmOut = Bitmap.createBitmap(width, height, b.getConfig());
        bmOut.setPixels(pixels, 0, width, 0, 0, width, height);
        return bmOut;
    }

    private Bitmap roundedCorner(Bitmap b, float round) {
        // image size
        int width = b.getWidth();
        int height = b.getHeight();
        // create bitmap output
        Bitmap result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        // set canvas for painting
        Canvas canvas = new Canvas(result);
        canvas.drawARGB(0, 0, 0, 0);

        // config paint
        final Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(Color.BLACK);

        // config rectangle for embedding
        final Rect rect = new Rect(0, 0, width, height);
        final RectF rectF = new RectF(rect);

        // draw rect to canvas
        canvas.drawRoundRect(rectF, round, round, paint);

        // create Xfer mode
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        // draw source image to canvas
        canvas.drawBitmap(b, rect, rect, paint);

        // return final image
        return result;
    }


    private Bitmap doColorBlue(Bitmap b) {
        // image size
        int width = b.getWidth();
        int height = b.getHeight();
        // create output bitmap
        Bitmap bmOut = Bitmap.createBitmap(width, height, b.getConfig());
        // color information
        int A, R, G, B;
        int pixel;

        // scan through all pixels
        for(int x = 0; x < width; ++x) {
            for(int y = 0; y < height; ++y) {
                // get pixel color
                pixel = b.getPixel(x, y);
                // apply filtering on each channel R, G, B
                A = Color.alpha(pixel);
                R = (int)(Color.red(pixel) * 0);
                G = (int)(Color.green(pixel) * 0);
                B = (int)(Color.blue(pixel) * 100);
                // set new color pixel to output bitmap
                bmOut.setPixel(x, y, Color.argb(A, R, G, B));
            }
        }

        // return final image
        return bmOut;
    }

    private Bitmap doColorGreen(Bitmap b) {
        // image size
        int width = b.getWidth();
        int height = b.getHeight();
        // create output bitmap
        Bitmap bmOut = Bitmap.createBitmap(width, height, b.getConfig());
        // color information
        int A, R, G, B;
        int pixel;

        // scan through all pixels
        for(int x = 0; x < width; ++x) {
            for(int y = 0; y < height; ++y) {
                // get pixel color
                pixel = b.getPixel(x, y);
                // apply filtering on each channel R, G, B
                A = Color.alpha(pixel);
                R = (int)(Color.red(pixel) * 0);
                G = (int)(Color.green(pixel) * 100);
                B = (int)(Color.blue(pixel) * 0);
                // set new color pixel to output bitmap
                bmOut.setPixel(x, y, Color.argb(A, R, G, B));
            }
        }

        // return final image
        return bmOut;
    }

    private Bitmap createContrast(Bitmap b, double value) {
        // image size
        int width = b.getWidth();
        int height = b.getHeight();
        // create output bitmap
        Bitmap bmOut = Bitmap.createBitmap(width, height, b.getConfig());
        // color information
        int A, R, G, B;
        int pixel;
        // get contrast value
        double contrast = Math.pow((100 + value) / 100, 2);

        // scan through all pixels
        for(int x = 0; x < width; ++x) {
            for(int y = 0; y < height; ++y) {
                // get pixel color
                pixel = b.getPixel(x, y);
                A = Color.alpha(pixel);
                // apply filter contrast for every channel R, G, B
                R = Color.red(pixel);
                R = (int)(((((R / 255.0) - 0.5) * contrast) + 0.5) * 255.0);
                if(R < 0) { R = 0; }
                else if(R > 255) { R = 255; }

                G = Color.red(pixel);
                G = (int)(((((G / 255.0) - 0.5) * contrast) + 0.5) * 255.0);
                if(G < 0) { G = 0; }
                else if(G > 255) { G = 255; }

                B = Color.red(pixel);
                B = (int)(((((B / 255.0) - 0.5) * contrast) + 0.5) * 255.0);
                if(B < 0) { B = 0; }
                else if(B > 255) { B = 255; }

                // set new pixel color to output bitmap
                bmOut.setPixel(x, y, Color.argb(A, R, G, B));
            }
        }

        // return final image
        return bmOut;
    }

    private Bitmap doGreyscale(Bitmap b) {
        // constant factors
        final double GS_RED = 0.299;
        final double GS_GREEN = 0.587;
        final double GS_BLUE = 0.114;

        // create output bitmap
        Bitmap bmOut = Bitmap.createBitmap(b.getWidth(), b.getHeight(), b.getConfig());
        // pixel information
        int A, R, G, B;
        int pixel;

        // get image size
        int width = b.getWidth();
        int height = b.getHeight();

        // scan through every single pixel
        for(int x = 0; x < width; ++x) {
            for(int y = 0; y < height; ++y) {
                // get one pixel color
                pixel = b.getPixel(x, y);
                // retrieve color of all channels
                A = Color.alpha(pixel);
                R = Color.red(pixel);
                G = Color.green(pixel);
                B = Color.blue(pixel);
                // take conversion up to one single value
                R = G = B = (int)(GS_RED * R + GS_GREEN * G + GS_BLUE * B);
                // set new pixel color to output bitmap
                bmOut.setPixel(x, y, Color.argb(A, R, G, B));
            }
        }

        // return final image
        return bmOut;
    }

    private Bitmap getScreenShot(View view) {
        view.setDrawingCacheEnabled(true);
        Bitmap bitmap=Bitmap.createBitmap(view.getDrawingCache());
        view.setDrawingCacheEnabled(false);
        return bitmap;
    }

    private void store(Bitmap filtered,String fileName) {
        String dirPath=Environment.getExternalStorageDirectory().getAbsolutePath()+"/FILTEREDIMAGES";
        File dir=new File(dirPath);
        if (!dir.exists()){
            dir.mkdirs();
        }
        File file=new File(dirPath,fileName);
        try {
            FileOutputStream fos=new FileOutputStream(file);
            filtered.compress(Bitmap.CompressFormat.PNG,100,fos);
            fos.flush();
            fos.close();
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private Bitmap doInvert(Bitmap b) {
        Bitmap bmOut = Bitmap.createBitmap(b.getWidth(), b.getHeight(), b.getConfig());
        // color info
        int A, R, G, B;
        int pixelColor;
        // image size
        int height = b.getHeight();
        int width = b.getWidth();

        // scan through every pixel
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                // get one pixel
                pixelColor = b.getPixel(x, y);
                // saving alpha channel
                A = Color.alpha(pixelColor);
                // inverting byte for each R/G/B channel
                R = 255 - Color.red(pixelColor);
                G = 255 - Color.green(pixelColor);
                B = 255 - Color.blue(pixelColor);
                // set newly-inverted pixel to output image
                bmOut.setPixel(x, y, Color.argb(A, R, G, B));
            }
        }

        // return final bitmap
        return bmOut;
    }

    @Override
    public void onClick(View view) {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,SELECTED_PICTURE);
        }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


                if (resultCode==RESULT_OK)
                {
                    if (requestCode==SELECTED_PICTURE){


                        Uri uri=data.getData();
                        InputStream inputStream;
                        try {
                            inputStream=getContentResolver().openInputStream(uri);

                            b = BitmapFactory.decodeStream(inputStream);
                            iv.setImageBitmap(b);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                            Toast.makeText(this, "Unable to open", Toast.LENGTH_SHORT).show();
                        }

                    }
                }
        }


}


package com.example.moviereviews;

/**
 * Created by asus on 7/27/2017.
 */

public class ReviewModel {
    String email,name;
    float rating;

    public ReviewModel() {
    }

    public ReviewModel(String email, String name, float rating) {
        this.email = email;
        this.name = name;
        this.rating = rating;
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public double getRating() {
        return rating;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }
}

package com.example.moviereviews;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;

public class RateActivity extends AppCompatActivity {

    private TextView tvname;
    private ImageView tvpic;
    private TextView tvdirector;
    private TextView tvyear;
    private EditText etrating;
    private TextView tvshowrating;
    private Button btnsubmit;
    private ArrayList<ReviewModel> items;
    private DatabaseReference db;
    private TextView tvavg;
    private RatingBar ratingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate);
        ratingBar = (RatingBar)findViewById(R.id.ratingBar);
        tvname = (TextView) findViewById(R.id.tvname);
        tvpic = (ImageView) findViewById(R.id.tvpic);
        tvdirector = (TextView) findViewById(R.id.tvdirector);
        tvyear = (TextView) findViewById(R.id.tvyear);
      //  etrating = (EditText) findViewById(R.id.etrating);
        tvshowrating = (TextView) findViewById(R.id.tvshowrating);
        tvavg=(TextView)findViewById(R.id.tvavg);
        btnsubmit = (Button) findViewById(R.id.btnsubmit);
        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String rate = String.valueOf(ratingBar.getRating());
                tvshowrating.setText(rate);
                String name = tvname.getText().toString();
                if (rate.isEmpty()) {
                    tvshowrating.setError("enter correct rating");
                    return;
                }
                FirebaseDatabase fbase = FirebaseDatabase.getInstance();//connecting cctivity to server
                FirebaseAuth auth = FirebaseAuth.getInstance();
                String email = auth.getCurrentUser().getEmail();
                //write to firebase
                DatabaseReference db = fbase.getReference("reviews");
                HashMap<String, Object> data = new HashMap<>();
                data.put("email", email);
                data.put("rating", Double.parseDouble(rate));
                data.put("name", name);
                db.push().setValue(data, new DatabaseReference.CompletionListener() {
                    @Override
                    public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                        if (databaseError == null) {
                            Toast.makeText(RateActivity.this, "data saved sucessfully!!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
        FirebaseDatabase fbase = FirebaseDatabase.getInstance();
        db = fbase.getReference("reviews");
        items = new ArrayList<>();

        Intent i = getIntent();
        if (i != null && i.getExtras() != null) {

            String name = i.getStringExtra("com.example.moviereviews.extra_name");
            String director = i.getStringExtra("com.example.moviereviews.extra_director");
            String year = i.getStringExtra("com.example.moviereviews.extra_year");
            String pic = i.getStringExtra("com.example.moviereviews.extra_pic");
            tvname.setText(name);
            tvdirector.setText(director);
            tvyear.setText(year);
            Picasso.with(this).load(pic).into(tvpic);
            loadReview(name);
        }

    }

    private void loadReview(final String name) {
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                items.clear();
                if (dataSnapshot.hasChildren()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (snapshot.child("name").getValue(String.class).equalsIgnoreCase(name)) {
                            items.add(snapshot.getValue(ReviewModel.class));
                        }
                    }
                    if (items.size() > 0) {
                        int ratingCount=items.size();
                        double sumOfRating=0.0;
                        for (ReviewModel item : items) {
                            sumOfRating+=item.getRating();
                        }
                        double avgRating=sumOfRating/ratingCount;
                        tvavg.setText(String.valueOf(avgRating));
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }


}

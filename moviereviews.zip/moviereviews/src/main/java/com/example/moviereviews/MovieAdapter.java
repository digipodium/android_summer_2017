package com.example.moviereviews;

import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by asus on 7/25/2017.
 */

public class MovieAdapter extends RecyclerView.Adapter<MoviesHolder> {
    private ArrayList<MovieModel> list;

    public MovieAdapter(ArrayList<MovieModel> items) {
        list = items;
    }

    @Override
    public MoviesHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.display, parent, false);
        MoviesHolder holder = new MoviesHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(final MoviesHolder holder, int position) {
        final MovieModel show = list.get(position);
        holder.tvname.setText(show.getName());
        Picasso.with(holder.tvpic.getContext()).load(show.getPic()).into(holder.tvpic);
        holder.tvdirector.setText(show.getDirector());
        holder.tvyear.setText("" + show.getYear());
        //extracton
        final String name= holder.tvname.getText().toString();
        final String director=holder.tvdirector.getText().toString();
        final String year=holder.tvyear.getText().toString();
        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(holder.card.getContext(),RateActivity.class);
                i.putExtra("com.example.moviereviews.extra_name",name);
                i.putExtra("com.example.moviereviews.extra_director",director);
                i.putExtra("com.example.moviereviews.extra_year",year);
                i.putExtra("com.example.moviereviews.extra_pic",show.getPic());
                holder.card.getContext().startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

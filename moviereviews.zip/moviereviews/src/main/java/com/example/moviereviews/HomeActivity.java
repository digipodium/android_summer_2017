package com.example.moviereviews;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {


    private Button btnhindi, btnenglish, btntamil, btntelugu, btnmalayalam, btnkannada, btnbengali, btnmarathi, btngujrati;
    private ArrayList<MovieModel> items;
    private MovieAdapter movieAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //
        loadMovies(null);
        items = new ArrayList<>();
        RecyclerView rvmovies = (RecyclerView) findViewById(R.id.rvmovies);
        rvmovies.setLayoutManager(new LinearLayoutManager(this));
        movieAdapter = new MovieAdapter(items);
        rvmovies.setAdapter(movieAdapter);
        btnhindi = (Button) findViewById(R.id.btnhindi);
        btnenglish = (Button) findViewById(R.id.btnenglish);
        btntamil = (Button) findViewById(R.id.btntamil);
        btntelugu = (Button) findViewById(R.id.btntelugu);
        btnmalayalam = (Button) findViewById(R.id.btnmalayalam);
        btnkannada = (Button) findViewById(R.id.btnkannada);
        btnbengali = (Button) findViewById(R.id.btnbengali);
        btnmarathi = (Button) findViewById(R.id.btnmarathi);
        btngujrati = (Button) findViewById(R.id.btngujrati);
        btnhindi.setOnClickListener(this);
        btnenglish.setOnClickListener(this);
        btntamil.setOnClickListener(this);
        btntelugu.setOnClickListener(this);
        btnmalayalam.setOnClickListener(this);
        btnkannada.setOnClickListener(this);
        btnbengali.setOnClickListener(this);
        btnmarathi.setOnClickListener(this);
        btngujrati.setOnClickListener(this);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_signout) {
            FirebaseAuth.getInstance().signOut();

            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
            finish();

            return true;
        }
        if (id == R.id.action_help) {
            Toast.makeText(this, "help is not avilable", Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onClick(View v) {
        String language = "";
        switch (v.getId()) {
            case R.id.btnhindi:
                loadMovies("hindi");
                break;
            case R.id.btnenglish:
                loadMovies("english");
                break;

            case R.id.btntelugu:
                loadMovies("telugu");
                break;

            case R.id.btntamil:
                loadMovies("tamil");
                break;
            case R.id.btnbengali:
                loadMovies("bengali");
                break;
            case R.id.btnkannada:
                loadMovies("kannada");
                break;
            case R.id.btngujrati:
                loadMovies("gujrati");
                break;
            case R.id.btnmalayalam:
                loadMovies("malayalam");
                break;
            case R.id.btnmarathi:
                loadMovies("marathi");
                break;
        }
    }

    private void loadMovies(final String filter) {
        final ProgressDialog dialog = new ProgressDialog(this);
        dialog.setMessage("Loading...");
        dialog.show();
        FirebaseDatabase fbase = FirebaseDatabase.getInstance();
        DatabaseReference db = fbase.getReference("movies");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChildren()) {
                    items.clear();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (filter == null) {
                            items.add(snapshot.getValue(MovieModel.class));
                        } else if (snapshot.child("language").getValue(String.class).equalsIgnoreCase(filter)) {
                            items.add(snapshot.getValue(MovieModel.class));
                        }
                    }
                    movieAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(HomeActivity.this, "Data not found!!", Toast.LENGTH_SHORT).show();
                }
                if (dialog.isShowing()) {
                    dialog.dismiss();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}


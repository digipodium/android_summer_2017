package com.example.moviereviews;

/**
 * Created by asus on 7/25/2017.
 */

public class MovieModel {

    private String name,director,pic;
    private int year;

    public MovieModel() {
    }

    public MovieModel(String name, String director, String pic, int year) {
        this.name = name;
        this.director = director;
        this.pic = pic;
        this.year = year;
    }

    public String getName() {
        return name;
    }

    public String getDirector() {
        return director;
    }

    public String getPic() {
        return pic;
    }

    public int getYear() {
        return year;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public void setYear(int year) {
        this.year = year;
    }
}

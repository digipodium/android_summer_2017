package com.example.moviereviews;

import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by asus on 7/25/2017.
 */

public class MoviesHolder extends RecyclerView.ViewHolder {

    public final TextView tvname,tvdirector,tvyear;
    public final ImageView tvpic;
    public final CardView card;

    public MoviesHolder(View itemView) {
        super(itemView);
        tvname=(TextView)itemView.findViewById(R.id.tvname);
        tvpic=(ImageView)itemView.findViewById(R.id.tvpic);
        tvdirector=(TextView)itemView.findViewById(R.id.tvdirector);
        tvyear=(TextView)itemView.findViewById(R.id.tvyear);
        card=(CardView)itemView.findViewById(R.id.card);

    }
}

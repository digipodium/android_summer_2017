package trainedge.my_alarm_clock;


import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.widget.Toast;

import java.security.Provider;

public class RingtonePlayService extends Service {

    MediaPlayer media_tone;
    int startId;
    boolean isRunning=false;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //Log.i("LocalService", "Received start id " + startId + ": " + intent);
        String state = intent.getExtras().getString("extra");

        switch (state) {
            case "alarm_on":
                startId = 1;
                break;
            case "alarm_off":
                startId = 0;
                break;
            default:
                startId = 1;
                break;
        }

        if(!this.isRunning){
           media_tone = MediaPlayer.create(this,R.raw.apple_ring);
            media_tone.start();

            this.isRunning = true;
            this.startId = 0;

        }
        else if(this.isRunning && startId==0){
            media_tone.stop();
            media_tone.reset();
            this.isRunning=false;
            this.startId=0;

        }
        else if(!this.isRunning && startId==0){
            this.isRunning = false;
            this.startId = 0;

        }
        else if(this.isRunning && startId==1){
            this.isRunning = true;
            this.startId = 1;

        }
        else{

        }

        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        Toast.makeText(this,"on Destroy called",Toast.LENGTH_SHORT).show();
    }





}

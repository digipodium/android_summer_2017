package trainedge.my_alarm_clock;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String get_your_string = intent.getExtras().getString("extra");
 //intent to ringtone service
        Intent service_intent = new Intent(context,RingtonePlayService.class);

        service_intent.putExtra("extra",get_your_string);

        //start the service
        context.startService(service_intent);
    }
}
